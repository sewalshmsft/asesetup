﻿#-------------------------------------------------------------------------------------
# <copyright file="Set-ASELan.ps1" company="Microsoft">
#     Copyright (c) Microsoft Corporation. All rights reserved.
# </copyright>
#-------------------------------------------------------------------------------------

<#

    .SYNOPSIS
    Updates the network configuration of a local Azure Stack Edge.

    .DESCRIPTION
    This script is used to update the LAN config of a local ASE so that
    it meets the requirements of Azure Orbital Cloud Access.

    .EXAMPLE
    PS> $asePassword = Read-Host -AsSecureString
    PS> .\Set-ASELAN.ps1 -ASESerial "ABC123XYZ" -ASEPassword $asePassword -LANIP "10.1.1.0" -SubnetMask "255.255.255.0" -LANGateway "10.1.1.1" -ZtpRestHelpersPath ".\\ZtpRestHelpers.ps1" -ComputePort 1

    .EXAMPLE
    PS> $asePassword = Read-Host -AsSecureString
    PS> .\Set-ASELAN.ps1 -ASESerial "XYZ123ABC" -ASEPassword $asePassword -LANIP "20.2.2.0" -SubnetMask "255.255.255.0" -LANGateway "20.2.2.1" -ZtpRestHelpersPath ".\\ZtpRestHelpers.ps1" -IsSDWAN -ComputePort 2

    .EXAMPLE
    PS> $asePassword = Read-Host -AsSecureString
    PS> .\Set-ASELAN.ps1 "123ABCXYZ" $asePassword "192.168.41.0" "255.255.255.0" "192.168.41.30" ".\\ZtpRestHelpers.ps1" -IsSDWAN -ComputePort 1

#>
[CmdletBinding()]
Param (
    
    [Parameter(Mandatory=$true)]
    [string]
    # Mandatory parameter. Specifies the serial number of your ASE.
    $ASESerial,
    
    [Parameter(Mandatory=$true)]
    [SecureString]
    # Mandatory parameter. Specifies the GUI password of your ASE.
    $ASEPassword,
    
    [ValidateScript({
        if(-Not ($_ -match[IPAddress]$_)) {
            throw "Please enter an IP address of a valid format."
        }
        return $true
    })]
    [IPAddress]
    # Specifies the IP subnet address of your LAN.
    $LANIP = "10.1.1.2",

    [ValidateScript({
        if(-Not ($_ -match[IPAddress]$_)) {
            throw "Please enter an IP address of a valid format."
        }
        return $true
    })]
    [string]
    # Subnet mask for the LAN IP. Defaults to 255.255.255.0, or /24
    $SubnetMask = "255.255.255.0",

    [ValidateScript({
        if(-Not ($_ -match[IPAddress]$_)) {
            throw "Please enter an IP address of a valid format."
        }
        if($_ -eq $LANIP){
            throw "Please enter a gateway different than the LAN IP."
        }
        return $true
    })]
    [IPAddress]
    # Specifies the gateway address of your LAN IP.
    $LANGateway = "10.1.1.1",

    [ValidateScript({
		if($_ -notmatch "(\.ps1)$"){
			throw "The file specified in the path argument must be of type ps1"
		}
		return $true 
	})]
    [Parameter(Mandatory=$true)]
    [string]
    # Path to ZTP rest helpers, required for configuring local ASE
    $ZtpRestHelpersPath,
    
    [switch]
    # Whether or not you are using an SD-WAN solution. Set to FALSE if left empty.
    $IsSDWAN

)

# BEGIN main process

# Import ZTP module
Import-Module $ZtpRestHelpersPath -Force

$ASEPW = Get-PlainTextPW -Password $ASEPassword

Try {

    # Set ASE login
    Set-Login "https://$($ASESerial).local" "$($ASEPW)" -ErrorAction Stop

}
Catch {

    # Prevent user password from surfacing on errors.
    throw ("$_".replace($ASEPW, "[redacted]"))
    
}

# Retrieve current configuration to work off of
$aseConfig = Get-DeviceConfiguration
    
# Check if get config call worked
if (-not $aseConfig) {

    throw "No configuration found, please ensure you are on the same network as your ASE. $_"

}
        
# If SD-WAN, port 3 must be used for LAN configuration, otherwise port 2
$LANPort = If ($IsSDWAN) { 3 } Else { 2 }

# Set transport ports, SATCOM is always 1, SECONDARY is either port 2 or N/A
$SATCOMPort = 1
$SECONDARYPort = If ($IsSDWAN) { 2 }

# Update network configuration object interfaces
$networkObj = $aseConfig.device.network
$networkObj.interfaces[$LANPort-1].isDhcpEnabled = "False"
$networkObj.interfaces[$LANPort-1].dnsServerAddresses = "8.8.8.8", "8.8.4.4"
$networkObj.interfaces[$LANPort-1].iPv4 = @{'address'=$LANIP.IPAddressToString; 'subnetMask'=$SubnetMask; 'gateway'=$LANGateway.IPAddressToString}
# ASE sets port 1 to static by default. Change this...
$networkObj.interfaces[0].isDhcpEnabled = "True"

# Update vSwitches

# Add SATCOM switch
$satcomJson = '{ "name":"SATCOM", "interfaces": [ "Port' + ($SATCOMPort) + '" ], "enabledForCompute":"false", "enabledForStorage":"false", "enabledForMgmt":"false", "supportsAcceleratedNetworking":"false", "enableEmbeddedTeaming":"false", "ipAddressPools":"" }'
$satcomObj = ConvertFrom-Json -InputObject $satcomJson
$networkObj.vSwitches += $satcomObj

# Add SECONDARY switch if applicable
If ($SECONDARYPort) {
    $secondaryJson = '{ "name":"SECONDARY", "interfaces": [ "Port' + ($SECONDARYPort) + '" ], "enabledForCompute":"false", "enabledForStorage":"false", "enabledForMgmt":"false", "supportsAcceleratedNetworking":"false", "enableEmbeddedTeaming":"false", "ipAddressPools":"" }'
    $secondaryObj = ConvertFrom-Json -InputObject $secondaryJson
    $networkObj.vSwitches += $secondaryObj
}

# Add LAN switch    
$LANJson = '{ "name":"LAN", "interfaces": [ "Port' + ($LANPort) + '" ], "enabledForCompute":"false", "enabledForStorage":"false", "enabledForMgmt":"false", "supportsAcceleratedNetworking":"false", "enableEmbeddedTeaming":"false", "ipAddressPools":"" }'
$LANObj = ConvertFrom-Json -InputObject $LANJson
$networkObj.vSwitches += $LANObj

# Grab current config status, in case changes are being made in real time
$curStatus = Get-DeviceConfigurationStatus

# Status can be complete if a config update was done recently...
If (($curStatus.deviceConfiguration.status -ne "None") -and ($curStatus.deviceConfiguration.status -ne "Complete")) {
    throw "This ASE is currently busy and has a configuration status of " + $curStatus.deviceConfiguration.status + ". Please try running this script again in a few minutes. If this continues to occur, restart your ASE."
}

# Prepare package to send to ASE
$pkg = New-Package -network $networkObj

$newConfig = Set-DeviceConfiguration -desiredDeviceConfig $pkg

# Loop through the current status until the update completes, checking every 10 seconds
$curStatus = Get-DeviceConfigurationStatus

$retryCount = 5

# Retry as there are times where we update the network we are connected to and so connectivity may be temporarily severed
while ($curStatus.deviceConfiguration.status -eq "InProgress" -and $retryCount -ne 0) {
    try {
        Write-Host -ForegroundColor Yellow "Configuration update status: $($curStatus.deviceConfiguration.status). Please wait..."
        Start-Sleep -Seconds 10
        $curStatus = Get-DeviceConfigurationStatus
    }
    catch {
        $lastErr = $_
        $retryCount = $retryCount - 1   
        Start-Sleep -Seconds 10
    }
}

if ($retryCount -eq 0) {
    throw $lastErr
}

# Grab results...
$resultString = $curStatus.deviceConfiguration.results | ConvertTo-Json

# If that result code is not Success, something went wrong during update. Result object will relay the issue to the user...
If ($curStatus.deviceConfiguration.results.resultCode -ne "Success") {
    throw "Something went wrong during configuration update: `n$($resultString)"
}

Write-Host -ForegroundColor Green "Successfully applied update to ASE: `n$($resultString)"