#-------------------------------------------------------------------------------------
# <copyright file="AOCA-Conductor.ps1" company="Microsoft">
#     Copyright (c) Microsoft Corporation. All rights reserved.
# </copyright>
#-------------------------------------------------------------------------------------

param (
    [parameter(mandatory)]
    [PSObject]
    $dayZeroMappings,
    [parameter(mandatory)] 
    [SecureString] 
    $password,
    [ValidateScript({
		if($_ -notmatch "(\.json)$"){
			throw "The file specified in the path argument must be of type template"
		}
		return $true 
	})]	
    [parameter(mandatory)]
    [string] 
    $conductorTemplatePath
)

function Update-ConductorIpAddress() {
    param (
        [Parameter()] [string] $PublicIpAddress,
        [Parameter()] [hashtable] $Headers,
        [Parameter()] [int] $RetryPeriodSeconds = 10,
        [Parameter()] [int] $MaxTries = 3
    )
    $Tries = 0
    $updatePublicIpAddressApi = "https://$PublicIpAddress/api/v1/config/candidate/authority?returnEntity=false"

    Write-Host -ForegroundColor Yellow "updatePublicIpAddressApi: " $updatePublicIpAddressApi

    $UpdatePayload = @{
                        "conductor-address" = @($PublicIpAddress)
                    }

    for($Tries; $Tries -lt $MaxTries; $Tries++) {                
        
        try {
            # The conductor does not have an official CA authority when freshly spun up, so we need to SkipCertificateCheck for any of the API calls to work properly.
            $suppressOutput = Invoke-RestMethod -Uri $updatePublicIpAddressApi -Method PATCH -Headers $Headers -Body ($UpdatePayload | ConvertTo-Json) -SkipCertificateCheck
            break;
        }
        catch [System.Net.WebException] {
            $ex = $_
            if($Tries -lt $MaxTries - 1) {
                Start-Sleep -Seconds $RetryPeriodSeconds
            }
        }
    }

    if($Tries -eq $MaxTries) {
        Write-Error ("Tried to update public ip address of conductor '{0}' {1}-times and failed" -f $updatePublicIpAddressApi, $Tries);
        Write-Error "Status Code: " $ex.Exception.Response.StatusCode
        throw $ex
    }
    Write-Host -ForegroundColor Yellow "The Ip Address has been added to conductor"
}

function Get-ConductorConfig() {
    param (
        [Parameter()] [string] $PublicIpAddress,
        [Parameter()] [hashtable] $Headers,
        [Parameter()] [int] $RetryPeriodSeconds = 10,
        [Parameter()] [int] $MaxTries = 3
    )

    $Tries = 0

    $configApi = "https://$PublicIpAddress/api/v1/config/getJSON"
    
    for($Tries; $Tries -lt $MaxTries; $Tries++) {
        try {
            # The conductor does not have an official CA authority when freshly spun up, so we need to SkipCertificateCheck for any of the API calls to work properly.
            $response = Invoke-RestMethod $configApi -Method GET -Headers $Headers -SkipCertificateCheck
            return $response
        } 
        catch [System.Net.WebException] {
            $ex = $_
            if($Tries -lt $MaxTries - 1) {
                Start-Sleep -Seconds $RetryPeriodSeconds
            }
        }
    }

    if($Tries -eq $MaxTries) {
        Write-Error ("Tried to get conductor config info '{0}' {1}-times and failed" -f $configApi, $Tries);
        Write-Error "Status Code: " $ex.Exception.Response.StatusCode
        throw $ex
    }
}

function Get-ConductorAssetId() {
    param (
        [Parameter()] [string] $ConductorName,
        [Parameter()] [string] $PublicIpAddress,
        [Parameter()] [hashtable] $Headers,
        [Parameter()] [int] $RetryPeriodSeconds = 10,
        [Parameter()] [int] $MaxTries = 3
    )
    $Tries = 0
    $getAssetIdApi = "https://$PublicIpAddress/api/v1/asset";
    
    for($Tries; $Tries -lt $MaxTries; $Tries++) {
        try {
            # The conductor does not have an official CA authority when freshly spun up, so we need to SkipCertificateCheck for any of the API calls to work properly.
            $response = Invoke-RestMethod $getAssetIdApi -Method GET -Headers $Headers -SkipCertificateCheck
            
            break;
        } 
        catch [System.Net.WebException] {
            $ex = $_
            if($Tries -lt $MaxTries - 1) {
                Start-Sleep -Seconds $RetryPeriodSeconds
            }
        }
    }

    if($Tries -eq $MaxTries) {
        Write-Error ("Tried to get conductor asset id '{0}' {1}-times and failed" -f $Uri, $Tries);
        Write-Error "Status Code: " $ex.Exception.Response.StatusCode
        throw $ex
    }
    
    $assetId = ""
    if($response -and [bool]$response.assetId) {
        $assetId = $response.assetId
    } else {
        throw ("No assetId found from the api: '{0}'" -f $getAssetIdApi)
    }
    return $assetId
}

function Update-ConductorAssetId() {
    param (
        [Parameter()] [string] $PublicIpAddress,
        [Parameter()] [string] $RouterName,
        [Parameter()] [string] $NodeName,
        [Parameter()] [string] $AssetId,
        [Parameter()] [hashtable] $Headers,
        [Parameter()] [int] $RetryPeriodSeconds = 10,
        [Parameter()] [int] $MaxTries = 3
    )
    $Tries = 0
    $assetIdUpdateApi = "https://$PublicIpAddress/api/v1/config/candidate/authority/router/$RouterName/node/$NodeName"
    $commitApi = "https://$PublicIpAddress/api/v1/config/commit"
    
    $requestBody = @{
        "asset-id" = @($AssetId)
    }

    $commitBody = @{
        "distributed" = $false;
        "warningsAsErrors" = $false
    }

    for($Tries; $Tries -lt $MaxTries; $Tries++) {
        try {
            # The conductor does not have an official CA authority when freshly spun up, so we need to SkipCertificateCheck for any of the API calls to work properly.
            $suppressOutput = Invoke-RestMethod -Uri $assetIdUpdateApi -Method PATCH -Headers $Headers -Body ($RequestBody | ConvertTo-Json) -SkipCertificateCheck
            $suppressOutput = Invoke-RestMethod -Uri $commitApi -Method POST -Headers $Headers -Body ($commitBody | ConvertTo-Json) -SkipCertificateCheck
            break;
        }
        catch [System.Net.WebException] {
            $ex = $_
            if($Tries -lt $MaxTries - 1) {
                Start-Sleep -Seconds $RetryPeriodSeconds
            }
        }

    }

    if($Tries -eq $MaxTries) {
        Write-Error ("Tried to update asset id of conductor '{0}' {1}-times and failed" -f $Uri, $Tries);
        Write-Error "Status Code: " $ex.Exception.Response.StatusCode
        throw $ex 
    }

    Write-Host -ForegroundColor Yellow "The asset id has been added to conductor"
}

$newline = [System.Environment]::NewLine

$cloudEnvironment = $dayZeroMappings.AzureEnvironmentOptions.CloudEnvironment
$subscriptionId = $dayZeroMappings.AzureInformation.TargetSubscriptionID
$tenantId = $dayZeroMappings.AzureInformation.TargetTenantID

$tokenSuppress = Get-AzBearerToken -cloudType $cloudEnvironment `
    -subscriptionID $subscriptionId `
    -tenantID $tenantId `
    -forceLogin

$guid = New-Guid

$conductorName = "Conductor-" + $guid.Guid.Split("-")[0]

$virtualNetworkName = $conductorName + "-vnet"

$nodeName = "Conductor-" + $guid.Guid.Split("-")[0]

$localPublicIpAddress = (Invoke-WebRequest -uri "https://ifconfig.me/ip").Content

Write-Host -ForegroundColor Yellow "localPublicIpAddress: " $localPublicIpAddress

$orbitalRPIPs = Get-OrbitalRPPublicIPs -cloudType $cloudEnvironment

$resourceGroupName = $dayZeroMappings.AzureInformation.TargetResourceGroupName
$location = $dayZeroMappings.AzureInformation.TargetRegion

$suppressOutput = New-AzResourceGroup -Name $resourceGroupName -Location $location -Force

$vNetIPAddressSpace = $dayZeroMappings.AzureInformation.AzurevNetIPAddressSpace
$MGMTSubnetIPAddressSpace = $dayZeroMappings.AzureInformation.AzurevNetMGMTSubnetAddressSpace

# Ensure the vnet ranges are valid
$parseErrors = ""

$parseErrors = (Test-CIDRNotation -cidrString $vNetIPAddressSpace -errVar $parseErrors -varName "dayZeroMappings.AzureInformation.AzurevNetIPAddressSpace")
$parseErrors = (Test-CIDRNotation -cidrString $MGMTSubnetIPAddressSpace -errVar $parseErrors -varName "dayZeroMappings.AzureInformation.AzurevNetMGMTSubnetAddressSpace")

if ($parseErrors.length -gt 0) {
	throw "Something went wrong validating the format of the provided IP addresses: $newline $newline$parseErrors"
}

$cloudInitScriptPath =  $dayZeroMappings.DayZeroFilePaths.ConductorCloudInitFilePath
$cloudInitScript = Remove-ScriptSpecialCharacters -scriptPath $cloudInitScriptPath
$formattedCIScript = $cloudInitScript -join "\n" `
    -replace '"', '\"'

(Get-Content $conductorTemplatePath) `
    -Replace('__conductor-name__', $conductorName) `
    -Replace('__node-name__', $nodeName) `
    -Replace('___OrbitalRPIPs___', $orbitalRPIPs) `
    -replace "___cloudInitScript___", $formattedCIScript `
    | Set-Content './conductor-template-tmp.json'

Write-Host -ForegroundColor Yellow "Deploying the conductor related resources under SubscriptionId:" $subscriptionId", ResourceGroup:" $resourceGroupName", in location:" $location

try {

    $sshPublicKey = $dayZeroMappings.JuniperInformation.ConductorSSHPublicKey
    $conductorSKUName =  $dayZeroMappings.JuniperInformation.ConductorOfferSKUName

    $suppressOutput = New-AzResourceGroupDeployment -ResourceGroupName $resourceGroupName `
        -TemplateFile './conductor-template-tmp.json' `
        -location $location `
        -localPublicIpAddress $localPublicIpAddress `
        -virtualNetworkName $virtualNetworkName `
        -sshPublicKey $sshPublicKey `
        -vNetIPAddressSpace $vNetIPAddressSpace `
        -MGMTSubnetIPAddressSpace $MGMTSubnetIPAddressSpace `
        -conductorSKUName $conductorSKUName `
        -Verbose `
        -ErrorAction Stop

    $publicIp = Get-AzPublicIpAddress -Name $conductorName"-publicIp"  -ResourceGroupName $resourceGroupName
    
    $ProviderObjectId = (Get-AzADServicePrincipal -DisplayName "Azure Orbital Resource Provider").id

    Update-RoleAssignment -ProviderObjectId $ProviderObjectId `
        -RoleDefinitionName "Contributor" `
        -Scope $publicIp.Id

    $publicIpAddress = $publicIp.IpAddress
    
    Write-Host -ForegroundColor Yellow "publicIp: " $publicIpAddress
    
    Write-Host -ForegroundColor Yellow "Sleeping for 180 seconds for conductor service spinning up."
    
    Start-Sleep -Seconds 180
    
    Write-Host -ForegroundColor Yellow "Sleep has been completed, attempting to login to the conductor."
    
    $plainpw = Get-PlainTextPW -Password $password
    
    $bearerToken = Get-ConductorToken -PublicIp $publicIpAddress -Username "admin" -Key $plainpw
    
    $headers = New-Object "System.Collections.Generic.Dictionary[[String],[String]]"
    $headers.Add("Authorization", "Bearer $bearerToken")
    $headers.Add("Content-Type", "application/json")
    
    Update-ConductorIpAddress -PublicIpAddress $publicIpAddress -Headers $headers
    
    $response = Get-ConductorConfig -PublicIpAddress $publicIpAddress -Headers $headers
    
    $routerName = $response.authority.router[0].name
    
    $nodeName = $response.authority.router[0].node[0].name
    
    Write-Host -ForegroundColor Yellow "router name: $routerName node name: $nodeName"
    
    $assetId = Get-ConductorAssetId -ConductorName $conductorName -PublicIpAddress $publicIpAddress -Headers $headers
    
    Write-Host -ForegroundColor Yellow "asset id: $assetId"
    
    Update-ConductorAssetId -PublicIpAddress $publicIpAddress -RouterName $routerName -AssetId $assetId -NodeName $nodeName -Headers $headers
}
catch {
    # If we run into any errors provisioning resources, we'll delete any intermediate resources that may have been created.
    Remove-ConductorResources -resourceGroupName $resourceGroupName -conductorName $conductorName
    Rename-Item -Path './conductor-template-tmp.json' -NewName "conductor-template-tmp.$(Get-Date -f yyyyMddHHmm).json"
    throw $_
}
finally {
    Remove-Item -Path './conductor-template-tmp.json' -ErrorAction SilentlyContinue
}

$deploymentOutput = @{virtualNetworkName=$virtualNetworkName;publicIpAddress=$publicIpAddress;conductorPublicIpResourceId=$publicIp.Id;conductorName=$conductorName}
return $deploymentOutput