#-------------------------------------------------------------------------------------
# <copyright file="Get-SSRVMInfo.ps1" company="Microsoft">
#     Copyright (c) Microsoft Corporation. All rights reserved.
# </copyright>
#-------------------------------------------------------------------------------------

[CmdletBinding()]
param(
    [Parameter(Mandatory = $true)]
    [string]
    $TargetVM,
    [Parameter(Mandatory = $true)]
    [string]
    $ASEResourceID,
    [ValidateScript({
		if($_ -notmatch "(\.sh)$"){
			throw "The file specified in the path argument must be of type sh"
		}
		return $true 
	})]	
    [Parameter(Mandatory = $true)]
    [string]
    $ShellScriptPath,
    [ValidateScript({
		if($_ -notmatch "(\.template)$"){
			throw "The file specified in the path argument must be of type template"
		}
		return $true 
	})]	
    [Parameter(Mandatory = $true)]
    [string]
    $CustomScriptTemplatePath,
    [parameter(mandatory)]
    [ValidateSet("commercial","government")]
    [string]
    $CloudEnvironment,
    [parameter(Mandatory = $true)]
    [string]
    $ASETenantID,
    [parameter(Mandatory = $true)]
    [Boolean]
    $IncludesAsusRouter,
    [string]
    $SecondarySubnetMask,
    [string]
    $SecondaryGateway
)


$resourceFieldArray = $ASEResourceID.split("/");
$ASESubscriptionID = $resourceFieldArray[2]
$ASEResourceGroupName = $resourceFieldArray[4]
$ASEResourceName = $resourceFieldArray[8]

$bearerToken = Get-AzBearerToken -cloudType $CloudEnvironment `
    -subscriptionID $ASESubscriptionID `
    -tenantID $ASETenantID

$targetASE = Get-AzResource -ResourceId $ASEResourceID

# ASE resource deployment needs to target the linked subscription
$linkedSubId = $targetASE.Properties.edgeProfile.subscription.id

$endpointInfo = Get-ManagementAPIEndpoint -cloudType $CloudEnvironment
$baseURI = $endpointInfo.baseURI
$apiVer = $endpointInfo.apiVer

$headers = New-Object "System.Collections.Generic.Dictionary[[String],[String]]"
$headers.Add("Authorization", "Bearer $bearerToken")
$headers.Add("Content-Type", "application/json")

$cseDeploymentURI = "$linkedSubId/linkedResourceGroups/ASERG/linkedProviders/Microsoft.Compute/virtualMachines/$TargetVM/extensions/CustomScript"

$customScript = Remove-ScriptSpecialCharacters -scriptPath $ShellScriptPath
$customScript = $customScript -join ";"

# This needs to be done for the PUT req to work properly
$customScript = $customScript `
    -replace '"', '\"' `
    -replace "'", "\'"

$customScriptExtensionTemplate = Get-Content -Path $CustomScriptTemplatePath -Raw
$customScriptExtensionTemplate = $customScriptExtensionTemplate `
    -replace "___script___", $customScript

$cseDeployResponse = Invoke-ASEWebRequest -uri "$baseURI/$cseDeploymentURI/$apiVer" `
    -method 'PUT' `
    -headers $headers `
    -body $customScriptExtensionTemplate

$cseDeployRawContent = $cseDeployResponse.RawContent
$rawContentArr = ($cseDeployRawContent -split '\r?\n').Trim()
$asyncOpURI = $rawContentArr[3].Substring($rawContentArr[3].IndexOf("https"))

Start-Sleep -s 5
Write-Host -ForegroundColor Green "Successfully sent Custom Script Extension request to the ASE. Checking status on operation: $asyncOpURI"
$cseResult = Watch-AsyncOperation `
    -asyncOpURI $asyncOpURI `
    -resourceType "Custom Script Extension" `
    -headers $headers

$outStart = $cseResult.IndexOf('[stdout]')
$errStart = $cseResult.IndexOf('[stderr]')

if ($outStart -eq -1 -or $errStart -eq -1) {
    throw "Custom Script Extension result is not in an expected format: $cseResult"
}

# Actual output is located between [stdout] and [stderr] tokens
$cseOutput = $cseResult.Substring($outStart + 9, $errStart - $outStart - 9).Trim()

$outArrStart = $cseOutput.IndexOf('(')
$newLine = [System.Environment]::NewLine

try {    
    $cseOutArr = $cseOutput.Substring($outArrStart) `
        -replace '[()'']', '' `
        -replace '[\[\]]', '"' `
        -replace '" "', "`" $newLine `"" `
        -replace '"', "" `
        | ConvertFrom-StringData
}
catch {
    # If something goes wrong during parsing, then the output of CSE was not as expected
    throw "Something went wrong when parsing the output of Custom Script Extension: $cseResult"
}

$edgeNetworkInfoOutput = Get-EdgeNetworkInfo -vmBusIdInput $cseOutArr `
    -cloudType $CloudEnvironment `
    -tenantID $ASETenantID `
    -subscriptionID $ASESubscriptionID `
    -resourceGroupName $ASEResourceGroupName `
    -ASEResourceName $ASEResourceName `
    -IncludesAsusRouter $IncludesAsusRouter `
    -SecondarySubnetMask $SecondarySubnetMask `
    -SecondaryGateway $SecondaryGateway

# This data will eventually be passed to AOCA resource creation
return $edgeNetworkInfoOutput