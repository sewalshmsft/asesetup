# !/usr/bin/env bash
# -------------------------------------------------------------------------------------
# <copyright file="StoreDayZeroMetrics.sh" company="Microsoft">
#     Copyright (c) Microsoft Corporation. All rights reserved.
# </copyright>
# -------------------------------------------------------------------------------------

interruptions=___interruptions___
totalTime=___totalTime___
metricStoreLocation="/etc/dayZeroMeasure/dayZeroMetrics.json"

mkdir -p "/etc/dayZeroMeasure"
printf "{\\n  \"Interruptions\": \"$interruptions\",\\n  \"TotalTime\": \"$totalTime\"\\n}">$metricStoreLocation

exit $?