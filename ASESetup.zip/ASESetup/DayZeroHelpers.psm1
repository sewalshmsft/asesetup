#-------------------------------------------------------------------------------------
# <copyright file="DayZeroHelpers.psm1" company="Microsoft">
#     Copyright (c) Microsoft Corporation. All rights reserved.
# </copyright>
#-------------------------------------------------------------------------------------

$global:successCodes = @("200", "202", "204")

<#
    .SYNOPSIS
    Invokes an ARM API call against an ASE. Returns the response of the API call.
#>
function Invoke-ASEWebRequest() {

    param (
        [Parameter(Mandatory = $true)]
        $uri,
        [Parameter(Mandatory = $true)]
        $method,
        [Parameter(Mandatory = $true)]
        $headers,
        [ValidateScript({
                if ($method -eq "PUT" -and ([string]::IsNullOrEmpty($_))) {
                    throw "Empty body for a PUT request"
                }
                return $true
            })]
        [Parameter(Mandatory = $false)]
        $body
    )

    # TODO ecaraballo: add more error handling
    if ($method -eq "PUT") { 
        $response = Invoke-WebRequest $uri -Method $method -Headers $headers -Body $body
    }
    else {
        $response = Invoke-WebRequest $uri -Method $method -Headers $headers        
    }
    $statusCode = $response.StatusCode
    
    if (-not ($successCodes -contains $statusCode)) {
        Write-Host -ForegroundColor Red "Get request for $uri was not successful. Status Code: $statusCode Response: $response"
        throw
    }
    else {
        return $response
    }

}

<#
    .SYNOPSIS
    Watches an async operation executed against an ASE for its status.
#>
function Watch-AsyncOperation() {

    # TODO ecaraballo: Think about adding a cap to amount of time to wait. ASE will go for 45m until it fails,
    # but that may be too long for a customer to wait.
    param(
        [Parameter(Mandatory = $true)]
        $asyncOpURI,
        [Parameter(Mandatory = $true)]
        $resourceType,
        [Parameter(Mandatory = $true)]
        $headers
    )

    do {
        
        $asyncOpResponse = Invoke-ASEWebRequest -uri $asyncOpURI `
            -method 'GET' `
            -headers $headers

        $rawContentArr = ($asyncOpResponse.RawContent -split '\r?\n').Trim()
        $asyncOpObj = $rawContentArr[-1] | ConvertFrom-Json -AsHashtable
        $asyncStatus = $asyncOpObj.status
        
        if ($asyncStatus -ne "Succeeded" -and $asyncStatus -ne "Failed") {
            Write-Host -ForegroundColor Yellow "$resourceType deployment status: $asyncStatus. Checking again in 15 seconds..."
            Start-Sleep -s 15
        }

    } while ($asyncStatus -ne "Succeeded" -and $asyncStatus -ne "Failed")

    if ($resourceType -ne "Custom Script Extension") {
        if ($asyncStatus -eq "Succeeded") {
            Write-Host -ForegroundColor Green "$resourceType deployment completed successfully!`n`n"
        }
        else {
            Write-Host -ForegroundColor Red "$resourceType deployment failure! $($asyncOpObj.error.message)"
            throw
        }
    }
    else {
        # CSE output on an ASE works by the script throwing an error, so we will not check for successful status codes.
        return $asyncOpObj.error.message
    }

}

<#
    .SYNOPSIS
    Returns management API endpoint information based off cloud type
#>
function Get-ManagementAPIEndpoint() {

    param(
        [Parameter(Mandatory)]
        [ValidateSet("commercial", "government")]
        $cloudType
    )

    if ($cloudType -eq "government") {
        $endpointInfo = @{
            baseURI = "https://management.usgovcloudapi.net"
            apiVer  = "?api-version=2020-06-01-preview"
        }
    }
    else {
        $endpointInfo = @{
            baseURI = "https://management.azure.com"
            apiVer  = "?api-version=2020-06-01-preview"
        }
    }

    return $endpointInfo
}

<#
    .SYNOPSIS
    Checks if the user is already logged in. If so, it returns the bearer token, otherwise it prompts the user to log in.
#>
function Get-AzBearerToken() {

    param(
        [Parameter(Mandatory)]
        [ValidateSet("commercial", "government")]
        $cloudType,
        [Parameter(Mandatory)]
        $subscriptionID,
        [Parameter(Mandatory)]
        $tenantID,
        [Parameter(Mandatory = $false)]
        [switch]
        $forceLogin
    )
    

    # There are some situations where we want to force the user to refresh their credentials
    if ($forceLogin) {
        Disconnect-AzAccount
    }
    else {
        $existingToken = Get-AzAccessToken -ErrorAction SilentlyContinue

        # Make sure the tenant of the existing token is the correct one
        if ($existingToken.TenantId -ne $tenantID) {
            $existingToken = [string]::empty
        }
    }

    if (-not $existingToken) {
        # Disconnect any existing AZ accounts
        Disconnect-AzAccount
    
        if ($cloudType -eq "government") {
            # Prompt customer for login credentials to Fairfax
            Connect-AzAccount -Environment AzureUSGovernment -Tenant $tenantID
        }
        else {
            # Prompt customer for login credentials to Commercial
            Connect-AzAccount -Environment AzureCloud -Tenant $tenantID
        }
    }
    
    # Added out-null to suppress the output of Set-AzContext, otherwise it gets appended to the bearer token...
    Set-AzContext -Subscription $subscriptionID -Tenant $tenantID | out-null

    $existingToken = Get-AzAccessToken
    
    $bearerToken = $existingToken.Token
    return $bearerToken
}

<#
    .SYNOPSIS
    This method removes all the comments from a given script. Comment format must be `# `.
#>
function Remove-ScriptSpecialCharacters {
    param(
        [Parameter(Mandatory = $true)]
        $scriptPath
    )

    # Read file, remove comments and blank lines
    $removedComments = (Get-Content -Path $scriptPath).Where({ $_ -ne "" }) | ForEach-Object {

        $line = $_

        # Trim() removes whitespace from both ends of string
        $trimmedLine = $line.Trim()

        # Check if what's left is either nothing or a comment
        if ([string]::IsNullOrEmpty($trimmedLine) -or $trimmedLine -match "^# ") {
            # if so, return nothing (inside foreach-object "return" acts like "coninue")
            return 
        }

        #take care of escape charaters inside the ssh public key
        if ($trimmedLine.contains('SSHPublicKey')) {
            $line = $line.Replace("\", "\\")
        }

        # See if non-empty line contains comment
        $commentIndex = $line.IndexOf("# ")

        if ($commentIndex -ge 0) {
            # if so, remove the comment
            $line = $line.Substring(0, $commentIndex)
        }

        # return $Line to $removedComments
        return $line
    }

    return $removedComments
}

<#
    .SYNOPSIS
    Runs a custom script against an Azure virtual machine via ARM custom script extension. Returns the async operation response result.
#>
function Invoke-CustomScriptExtensionRequest {
    param(
        [Parameter(Mandatory)]
        $dayZeroMappings,
        [Parameter(Mandatory)]
        [string]
        $targetVmName,
        [System.Collections.Generic.Dictionary[[String], [String]]]
        $scriptReplacements,
        [string]
        $scriptPath
    )

    # Get parameters from inputs
    $targetAseId = $dayZeroMappings.AzureStackEdgeInformation.AzureStackEdgeResourceID
    $targetAseTenantId = $dayZeroMappings.AzureStackEdgeInformation.AzureStackEdgeTenantID
    $cloudEnvironment = $dayZeroMappings.AzureEnvironmentOptions.CloudEnvironment
    $cseTemplatePath = $dayZeroMappings.DayZeroFilePaths.CustomScriptTemplatePath

    # Parse needed values from ASE resource ID
    $resourceFieldArray = $targetAseId.split("/")
    $aseSubscriptionId = $resourceFieldArray[2]

    # Authenticate to ASE with bearer token and get ASE resource
    $bearerToken = Get-AzBearerToken -cloudType $cloudEnvironment `
        -subscriptionID $aseSubscriptionId `
        -tenantID $targetAseTenantId

    $targetAse = Get-AzResource -ResourceId $targetAseId

    # Generate CSE call headers and URI
    $linkedSubscriptionId = $targetAse.Properties.edgeProfile.subscription.id

    $endpointInfo = Get-ManagementAPIEndpoint -cloudType $cloudEnvironment
    $baseUri = $endpointInfo.baseURI
    $apiVersion = $endpointInfo.apiVer

    $headers = New-Object "System.Collections.Generic.Dictionary[[String],[String]]"
    $headers.Add("Authorization", "Bearer $bearerToken")
    $headers.Add("Content-Type", "application/json")

    $cseDeploymentUri = "$linkedSubscriptionId/linkedResourceGroups/ASERG/linkedProviders/Microsoft.Compute/virtualMachines/$targetVmName/extensions/CustomScript"

    # Prepare script and CSE deploy template
    $customScript = Remove-ScriptSpecialCharacters -scriptPath $scriptPath 
    $customScript = $customScript -join ";"
    $customScript = $customScript `
        -replace '"', '\"' `
        -replace "'", "\'"

    if ($PSBoundParameters.ContainsKey('scriptReplacements')) {
        foreach ($scriptReplacementKey in $scriptReplacements.Keys) {
            $customScript = $customScript `
                -replace $scriptReplacementKey, $scriptReplacements[$scriptReplacementKey]
        }
    }

    $cseTemplate = Get-Content -Path $cseTemplatePath -Raw
    $cseTemplate = $cseTemplate `
        -replace "___script___", $customScript

    # Invoke CSE deploy request, capture response
    $cseDeployResponse = Invoke-ASEWebRequest -uri "$baseUri/$cseDeploymentUri/$apiVersion" `
        -method 'PUT' `
        -headers $headers `
        -body $cseTemplate

    $cseDeployRawContent = $cseDeployResponse.RawContent
    $rawContentArr = ($cseDeployRawContent -split '\r?\n').Trim()
    $asyncOpURI = $rawContentArr[3].Substring($rawContentArr[3].IndexOf("https"))
    
    Start-Sleep -s 5

    # Watch async operation afterward and return result when ready
    Write-Host -ForegroundColor Green "Successfully sent Custom Script Extension request to the ASE. Checking status on operation."
    $cseResult = Watch-AsyncOperation `
        -asyncOpURI $asyncOpUri `
        -resourceType "Custom Script Extension" `
        -headers $headers

    return $cseResult
}

<#
    .SYNOPSIS
    Prepares for and calls the CSE to emit day0 metrics
#>
function Emit-DayZeroMetrics {
    param(
        [Parameter(Mandatory)]
        $dayZeroMappings,
        [Parameter(Mandatory)]
        $dayZeroInterruptions,
        [Parameter(Mandatory)]
        $dayZeroTimer
    )

    $dayZeroInterruptionsTotal = 0
    $dayZeroTotalTime = 0
    $dayZeroInterruptionsTotal = ($dayZeroInterruptions | Measure-Object -Sum).Sum
    $dayZeroTotalTime = ($dayZeroTimer | Measure-Object -Sum).Sum

    #set up to run CSE
    try {
        # Get the name of the newly-deployed AOCA agent
        $agentVmName = Watch-AocaAgentVmDeployment `
            -targetAseId $dayZeroMappings.AzureStackEdgeInformation.AzureStackEdgeResourceID `
            -targetAseTenantId $dayZeroMappings.AzureStackEdgeInformation.AzureStackEdgeTenantID `
            -cloudEnvironment $dayZeroMappings.AzureEnvironmentOptions.CloudEnvironment

        # Build token replacement mapping the below cmdlet will use to replace placeholder values with metric values in script
        $scriptReplacements = New-Object "System.Collections.Generic.Dictionary[[String],[String]]"
        $scriptReplacements.Add("___interruptions___", $dayZeroInterruptionsTotal)
        $scriptReplacements.Add("___totalTime___", $dayZeroTotalTime)

        # Invoke Custom Script Extension request to write metrics to agent VM
        $cseResult = Invoke-CustomScriptExtensionRequest `
            -dayZeroMappings $dayZeroMappings `
            -targetVmName $agentVmName `
            -scriptReplacements $scriptReplacements `
            -scriptPath $dayZeroMappings.DayZeroFilePaths.MetricsScriptFilePath
    }
    catch {
        #For now, don't do anything with an error caught sending day0 metrics
    }

    return $cseResult;
}

<#
    .SYNOPSIS
    Returns the string name of the AOCA agent currently running on this ASE, by querying a list of virtual machines on
    this ASE belonging to resource group "ASERG" and returning the first which whose name begins with 'aoca-' and status is running
#>
function Watch-AocaAgentVmDeployment {
    param(
        [Parameter(Mandatory)]
        [string]
        $targetAseId,
        [Parameter(Mandatory)]
        [string]
        $targetAseTenantId,
        [Parameter(Mandatory)]
        [ValidateSet("commercial", "government")]
        [string]
        $cloudEnvironment
    )

    # Parse needed values from ASE resource ID
    $resourceFieldArray = $targetAseId.split("/")
    $aseSubscriptionId = $resourceFieldArray[2]

    # Authenticate to ASE with bearer token and get ASE resource
    $bearerToken = Get-AzBearerToken -cloudType $cloudEnvironment `
        -subscriptionID $aseSubscriptionId `
        -tenantID $targetAseTenantId

    $targetAse = Get-AzResource -ResourceId $targetAseId
    $linkedSubscriptionId = $targetAse.Properties.edgeProfile.subscription.id

    # Assemble request URI and headers
    $endpointInfo = Get-ManagementAPIEndpoint -cloudType $cloudEnvironment
    $baseUri = $endpointInfo.baseURI
    $apiVersion = $endpointInfo.apiVer

    $headers = New-Object "System.Collections.Generic.Dictionary[[String],[String]]"
    $headers.Add("Authorization", "Bearer $bearerToken")
    $headers.Add("Content-Type", "application/json")

    $virtualMachinesUri = "$linkedSubscriptionId/linkedResourceGroups/ASERG/linkedProviders/Microsoft.Compute/virtualMachines"

    # Now, once every half minute, query for virtual machines and look for one whose name beings with "aoca-" and has status "PowerState/running"
    $attempts = 60

    while ($attempts -gt 0)
    {
        # Send web request for virtual machine list, capture response
        $virtualMachinesResponse = Invoke-ASEWebRequest -uri "$baseUri/$virtualMachinesUri/$apiVersion" `
        -method 'GET' `
        -headers $headers

        # We should receive a JSON with top-level property "value" that contains a list of JSON VM objects on this ASE.
        # Since in practice we will have one AOCA agent running on an ASE, we can iterate through VMs in resource group
        # 'ASERG' and take the first that starts with agent VM name prefix 'aoca-'
        $virtualMachinesResponseJson = ConvertFrom-Json $virtualMachinesResponse
        $virtualMachineList = $virtualMachinesResponseJson.value

        # Clear virtual machine name between runs to display correct retry message
        $virtualMachineName = ""

        foreach ($virtualMachine in $virtualMachineList) {
            if ($virtualMachine.name.StartsWith("aoca-")) {
                $virtualMachineName = $virtualMachine.name

                # If we find the VM we're looking for, also query and verify status is PowerState/running
                $virtualMachineStatusUri = "$linkedSubscriptionId/linkedResourceGroups/ASERG/linkedProviders/Microsoft.Compute/virtualMachines/$virtualMachineName/instanceView"

                $virtualMachineResponse = Invoke-WebRequest -uri "$baseUri/$virtualMachineStatusUri/$apiVersion" `
                -method 'GET' `
                -headers $headers
        
                # We should receive an object with detailed information about the virtual machine. We can find the status at response.statuses[1].code
                $virtualMachineResponseJson = ConvertFrom-Json $virtualMachineResponse
                $virtualMachineStatus = $virtualMachineResponseJson.statuses[1].code

                if ($virtualMachineStatus -eq "PowerState/running") {
                    Write-Host -ForegroundColor Yellow "Found running Azure Orbital Cloud Access agent VM $virtualMachineName!"
                    return $virtualMachineName
                }
                else {
                    break
                }
            }
        }

        if ($virtualMachineName -eq "") {
            Write-Host -ForegroundColor Yellow "Did not find any Azure Orbital Cloud Access agent VM, retrying in thirty seconds..."
        }
        else {
            Write-Host -ForegroundColor Yellow "Found Azure Orbital Cloud Access agent VM $virtualMachineName but status was $virtualMachineStatus, retrying in thirty seconds..."
        }

        $attempts = $attempts - 1
        Start-Sleep -s 30
    }

    # If after 30 tries we still haven't found a running AOCA agent, throw error
    throw "Did not find running Azure Orbital Cloud Access agent VM on Azure Stack Edge. Please ensure Azure Orbital Cloud Access agent has deployed and is running then re-run the script."
}

<#
    .SYNOPSIS
    Converts a SecureString variable into plaintext. Method changes depending on the PS version.
#>
function Get-PlainTextPW() {
    param(
        [Parameter(Mandatory = $true)]
        [SecureString] $Password
    )

    # Grab users PS version
    $userPSVersion = $PSVersionTable.PSVersion.Major

    # Method to de-crypt password changes depending on the PS Version
    If ($userPSVersion -le 5) {

        $bString = [System.Runtime.InteropServices.Marshal]::SecureStringToBSTR($Password)
        $plainPW = [System.Runtime.InteropServices.Marshal]::PtrToStringAuto($bString)
        
    }
    Else {
    
        $plainPW = ConvertFrom-SecureString -SecureString $Password -AsPlainText

    }

    return $plainPW

}

<#
    .SYNOPSIS
    Coverts a subnet mask to CIDR notation
#>
function Convert-Subnetmask {
    [CmdLetBinding(DefaultParameterSetName = 'CIDR')]
    param( 
        [Parameter( 
            ParameterSetName = 'CIDR',       
            Position = 0,
            Mandatory = $true,
            HelpMessage = 'CIDR like /24 without "/"')]
        [ValidateRange(0, 32)]
        [Int32]$CIDR,

        [Parameter(
            ParameterSetName = 'Mask',
            Position = 0,
            Mandatory = $true,
            HelpMessage = 'Subnetmask like 255.255.255.0')]
        [ValidateScript({
                if ($_ -match "^(254|252|248|240|224|192|128).0.0.0$|^255.(254|252|248|240|224|192|128|0).0.0$|^255.255.(254|252|248|240|224|192|128|0).0$|^255.255.255.(255|254|252|248|240|224|192|128|0)$") {
                    return $true
                }
                else {
                    throw "Provided subnet mask $_ is not a valid mask (e.g. 255.255.255.0)"
                }
            })]
        [String]$Mask
    )

    Begin {

    }

    Process {
        switch ($PSCmdlet.ParameterSetName) {
            "CIDR" {                          
                # Make a string of bits (24 to 11111111111111111111111100000000)
                $CIDR_Bits = ('1' * $CIDR).PadRight(32, "0")
                
                # Split into groups of 8 bits, convert to Ints, join up into a string
                $Octets = $CIDR_Bits -split '(.{8})' -ne ''
                $Mask = ($Octets | ForEach-Object -Process { [Convert]::ToInt32($_, 2) }) -join '.'
            }

            "Mask" {
                # Convert the numbers into 8 bit blocks, join them all together, count the 1
                $Octets = $Mask.ToString().Split(".") | ForEach-Object -Process { [Convert]::ToString($_, 2) }
                $CIDR_Bits = ($Octets -join "").TrimEnd("0")

                # Count the "1" (111111111111111111111111 --> /24)                     
                $CIDR = $CIDR_Bits.Length             
            }               
        }

        [pscustomobject] @{
            Mask = $Mask
            CIDR = $CIDR
        }
    }

    End {
        
    }
}

<#
    .SYNOPSIS
    Attempts to parse a string into an IP address
#>
function Test-IPAddressParse {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $true)]
        [AllowEmptyString()]
        [string]$ipString,
        [Parameter(Mandatory = $true)]
        [AllowEmptyString()]
        [string]$errVar,
        [Parameter(Mandatory = $true)]
        [string]$varName
    )

    $newline = [System.Environment]::NewLine

    try {
        $ip = [IPAddress]$ipString
    }
    catch {
        $errVar = $errVar + "$varName - $($_.Exception.Message) $newline $newline"
    }

    return $errVar
}

<#
    .SYNOPSIS
    Ensures the provided CIDR notation is correct
#>
function Test-CIDRNotation {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $true)]
        [AllowEmptyString()]
        [string]$cidrString,
        [Parameter(Mandatory = $true)]
        [AllowEmptyString()]
        [string]$errVar,
        [Parameter(Mandatory = $true)]
        [string]$varName
    )

    $newline = [System.Environment]::NewLine

    $cidr = $cidrString.split("/")

    if ($cidr.length -ne 2) {
        $errVar = $errVar + "$varName - CIDR value $cidrString is not in the expected fromat of <IP>/<MASK> e.g. 192.168.0.0/24. $newline $newline"
        return $errVar
    } 

    $errVar = (Test-IPAddressParse -ipString $cidr[0] -errVar $errVar -varName $varName)

    if (-not ($cidr[1] -ge 0 -and $cidr[1] -le 32)) {
        $errVar = $errVar + "$varName - CIDR mask value $($cidr[1]) falls outside of the numerical range 0-32. $newline $newline"
    }

    return $errVar
}

<#
    .SYNOPSIS
    Deletes all conductor resources in a specified resource group. Only ran if something goes wrong during
    Conductor deployment

    # TODO ecaraballo: refer to https://msazure.visualstudio.com/DefaultCollection/One/_git/Azure-Orbital/pullRequest/8037602#1683688026
#>
function Remove-ConductorResources() {
    param (
        [Parameter()] [string] $resourceGroupName,
        [Parameter()] [string] $conductorName
    )

    $securityGroupName = $conductorName + "-sg"
    $publicIpName = $conductorName + "-publicIp"
    $availabilitySetName = $conductorName + "-as"
    $virtualNetworkName = $conductorName + "-vnet"
    $networkInterfaceName = $conductorName + "-network-interface"
    $diskName = $conductorName + "-disk"
    $mgmtSubnetName = $virtualNetworkName + "/MGMT"


    Remove-AzResource `
        -ResourceGroupName $resourceGroupName `
        -ResourceName $conductorName `
        -ResourceType "Microsoft.Compute/virtualMachines" `
        -Force `
        -ErrorAction SilentlyContinue

    Remove-AzResource `
        -ResourceGroupName $resourceGroupName `
        -ResourceName $diskName `
        -ResourceType "Microsoft.Compute/disks" `
        -Force `
        -ErrorAction SilentlyContinue
    
    Remove-AzResource `
        -ResourceGroupName $resourceGroupName `
        -ResourceName $availabilitySetName `
        -ResourceType "Microsoft.Compute/availabilitySets" `
        -Force `
        -ErrorAction SilentlyContinue

    Remove-AzResource `
        -ResourceGroupName $resourceGroupName `
        -ResourceName $networkInterfaceName `
        -ResourceType "Microsoft.Network/networkInterfaces" `
        -Force `
        -ErrorAction SilentlyContinue
    
    Remove-AzResource `
        -ResourceGroupName $resourceGroupName `
        -ResourceName $mgmtSubnetName `
        -ResourceType "Microsoft.Network/virtualNetworks/subnets" `
        -Force `
        -ErrorAction SilentlyContinue

    Remove-AzResource `
        -ResourceGroupName $resourceGroupName `
        -ResourceName $virtualNetworkName `
        -ResourceType "Microsoft.Network/virtualNetworks" `
        -Force `
        -ErrorAction SilentlyContinue

    Remove-AzResource `
        -ResourceGroupName $resourceGroupName `
        -ResourceName $publicIpName `
        -ResourceType "Microsoft.Network/publicIPAddresses" `
        -Force `
        -ErrorAction SilentlyContinue

    Remove-AzResource `
        -ResourceGroupName $resourceGroupName `
        -ResourceName $securityGroupName `
        -ResourceType "Microsoft.Network/networkSecurityGroups" `
        -Force `
        -ErrorAction SilentlyContinue

}

<#
    .SYNOPSIS
    Deletes all SSR resources in a specified resource group. Only ran if something goes wrong during
    Azure SSR deployment
#>
function Remove-CloudSSRResources() {
    param (
        [Parameter()] [string] $resourceGroupName,
        [Parameter()] [string] $cloudSSRName,
        [Parameter()] [string] $virtualNetworkName
    )

    $mgmtName = $cloudSSRName + "-mgmt"
    $publicName = $cloudSSRName + "-public"
    $privateName = $cloudSSRName + "-private"
    $availabilitySetName = $cloudSSRName + "-as"
    $diskName = $cloudSSRName
    $routeTableName = $cloudSSRName + "-routeTable"
    $routeName = $routeTableName + "/LAN_NextHop"
    $wanSubnetName = $virtualNetworkName + "/WAN"
    $lanSubnetName = $virtualNetworkName + "/LAN"

    Remove-AzResource `
        -ResourceGroupName $resourceGroupName `
        -ResourceName $cloudSSRName `
        -ResourceType "Microsoft.Compute/virtualMachines" `
        -Force `
        -ErrorAction SilentlyContinue

    Remove-AzResource `
        -ResourceGroupName $resourceGroupName `
        -ResourceName $diskName `
        -ResourceType "Microsoft.Compute/disks" `
        -Force `
        -ErrorAction SilentlyContinue
    
    Remove-AzResource `
        -ResourceGroupName $resourceGroupName `
        -ResourceName $availabilitySetName `
        -ResourceType "Microsoft.Compute/availabilitySets" `
        -Force `
        -ErrorAction SilentlyContinue

    Remove-AzResource `
        -ResourceGroupName $resourceGroupName `
        -ResourceName $mgmtName `
        -ResourceType "Microsoft.Network/networkInterfaces" `
        -Force `
        -ErrorAction SilentlyContinue

    Remove-AzResource `
        -ResourceGroupName $resourceGroupName `
        -ResourceName $mgmtName `
        -ResourceType "Microsoft.Network/publicIPAddresses" `
        -Force `
        -ErrorAction SilentlyContinue

    Remove-AzResource `
        -ResourceGroupName $resourceGroupName `
        -ResourceName $mgmtName `
        -ResourceType "Microsoft.Network/networkSecurityGroups" `
        -Force `
        -ErrorAction SilentlyContinue

    Remove-AzResource `
        -ResourceGroupName $resourceGroupName `
        -ResourceName $publicName `
        -ResourceType "Microsoft.Network/networkInterfaces" `
        -Force `
        -ErrorAction SilentlyContinue

    Remove-AzResource `
        -ResourceGroupName $resourceGroupName `
        -ResourceName $publicName `
        -ResourceType "Microsoft.Network/publicIPAddresses" `
        -Force `
        -ErrorAction SilentlyContinue

    Remove-AzResource `
        -ResourceGroupName $resourceGroupName `
        -ResourceName $wanSubnetName `
        -ResourceType "Microsoft.Network/virtualNetworks/subnets" `
        -Force `
        -ErrorAction SilentlyContinue

    Remove-AzResource `
        -ResourceGroupName $resourceGroupName `
        -ResourceName $publicName `
        -ResourceType "Microsoft.Network/networkSecurityGroups" `
        -Force `
        -ErrorAction SilentlyContinue

    Remove-AzResource `
        -ResourceGroupName $resourceGroupName `
        -ResourceName $privateName `
        -ResourceType "Microsoft.Network/networkInterfaces" `
        -Force `
        -ErrorAction SilentlyContinue
    
    Remove-AzResource `
        -ResourceGroupName $resourceGroupName `
        -ResourceName $lanSubnetName `
        -ResourceType "Microsoft.Network/virtualNetworks/subnets" `
        -Force `
        -ErrorAction SilentlyContinue

    Remove-AzResource `
        -ResourceGroupName $resourceGroupName `
        -ResourceName $privateName `
        -ResourceType "Microsoft.Network/networkSecurityGroups" `
        -Force `
        -ErrorAction SilentlyContinue

    Remove-AzResource `
        -ResourceGroupName $resourceGroupName `
        -ResourceName $routeName `
        -ResourceType "Microsoft.Network/routeTables/routes" `
        -Force `
        -ErrorAction SilentlyContinue
    
    Remove-AzResource `
        -ResourceGroupName $resourceGroupName `
        -ResourceName $routeTableName `
        -ResourceType "Microsoft.Network/routeTables" `
        -Force `
        -ErrorAction SilentlyContinue
}

<#
    .SYNOPSIS
    Deletes all of the Azure resources for no-SDWAN deployment in case of a failure. 
    THE ORDER HERE IS VERY IMPORTANT.
#>
function Remove-NSDAzureNetworkingResources() {
    param (
        [Parameter()] [string] $resourceGroupName,
        [Parameter()] [string] $resourcePrefix
    )

    $firewallName = $resourcePrefix + "-fw"
    $firewallPipName = $resourcePrefix + "-fw-pip"
    $firewallPolicyName = $resourcePrefix + "-fw-policy"
    $vpnGatewayConnectionName = $resourcePrefix + "-vpngw-connection"
    $localNetworkGatewayName = $resourcePrefix + "-lng"
    $vpnGatewayName = $resourcePrefix + "-vpngw"
    $vpnGatewayPipName = $resourcePrefix + "-vpngw-pip"
    $vnetName = $resourcePrefix + "-vnet"
    $firewallRouteTableName = $resourcePrefix + "-fw-route"
    $vpnGatewayRouteTableName = $resourcePrefix + "-vpngw-route"

    Remove-AzResource `
        -ResourceGroupName $resourceGroupName `
        -ResourceName $firewallName `
        -ResourceType "Microsoft.Network/azureFirewalls" `
        -Force `
        -ErrorAction SilentlyContinue

    Remove-AzResource `
        -ResourceGroupName $resourceGroupName `
        -ResourceName $firewallPipName `
        -ResourceType "Microsoft.Network/publicIPAddresses" `
        -Force `
        -ErrorAction SilentlyContinue

    Remove-AzResource `
        -ResourceGroupName $resourceGroupName `
        -ResourceName $firewallPolicyName `
        -ResourceType "Microsoft.Network/firewallPolicies" `
        -Force `
        -ErrorAction SilentlyContinue

    Remove-AzResource `
        -ResourceGroupName $resourceGroupName `
        -ResourceName $vpnGatewayConnectionName `
        -ResourceType "Microsoft.Network/connections" `
        -Force `
        -ErrorAction SilentlyContinue

    Remove-AzResource `
        -ResourceGroupName $resourceGroupName `
        -ResourceName $localNetworkGatewayName `
        -ResourceType "Microsoft.Network/localNetworkGateways" `
        -Force `
        -ErrorAction SilentlyContinue

    Remove-AzResource `
        -ResourceGroupName $resourceGroupName `
        -ResourceName $vpnGatewayName `
        -ResourceType "Microsoft.Network/virtualNetworkGateways" `
        -Force `
        -ErrorAction SilentlyContinue

    Remove-AzResource `
        -ResourceGroupName $resourceGroupName `
        -ResourceName $vpnGatewayPipName `
        -ResourceType "Microsoft.Network/publicIPAddresses" `
        -Force `
        -ErrorAction SilentlyContinue

    Remove-AzResource `
        -ResourceGroupName $resourceGroupName `
        -ResourceName $vnetName `
        -ResourceType "Microsoft.Network/virtualNetworks" `
        -Force `
        -ErrorAction SilentlyContinue

    Remove-AzResource `
        -ResourceGroupName $resourceGroupName `
        -ResourceName $firewallRouteTableName `
        -ResourceType "Microsoft.Network/routeTables" `
        -Force `
        -ErrorAction SilentlyContinue

    Remove-AzResource `
        -ResourceGroupName $resourceGroupName `
        -ResourceName $vpnGatewayRouteTableName `
        -ResourceType "Microsoft.Network/routeTables" `
        -Force `
        -ErrorAction SilentlyContinue
}

<#
    .SYNOPSIS
    Installs Bicep, required for RG deployments that use bicep instead of ARM templates.
#>
function Install-Bicep() {

    try {
        $suppress = bicep --help
    }
    catch {
        # Create the install folder
        $installPath = "$env:USERPROFILE\.bicep"
        $installDir = New-Item -ItemType Directory -Path $installPath -Force
        $installDir.Attributes += 'Hidden'
        # Fetch the latest Bicep CLI binary
        (New-Object Net.WebClient).DownloadFile("https://github.com/Azure/bicep/releases/latest/download/bicep-win-x64.exe", "$installPath\bicep.exe")
        # Add bicep to your PATH
        $currentPath = (Get-Item -path "HKCU:\Environment" ).GetValue('Path', '', 'DoNotExpandEnvironmentNames')
        if (-not $currentPath.Contains("%USERPROFILE%\.bicep")) { setx PATH ($currentPath + ";%USERPROFILE%\.bicep") }
        if (-not $env:path.Contains($installPath)) { $env:path += ";$installPath" }
    }
}

<#
    .SYNOPSIS
    Based on vmBusIdInput info, extract the vmBusId based on the private subnet octets and public subnet octets
#>
Function Get-VMBusIdInfo
{
    [cmdletbinding()]
    Param 
    (
        [object]
        [parameter(mandatory=$true)] $vmBusIdInput,
        [string] 
        [Parameter()] 
        $publicSubnetPrefix,
        [string] 
        [Parameter()] 
        $privateSubnetPrefix
    )

    $eth1Value = $vmBusIdInput["eth1"];
    $eth2Value = $vmBusIdInput["eth2"];
    $eth1Array = $eth1Value.split(" ");
    $eth2Array = $eth2Value.split(" ");
    $assetId = $vmBusIdInput["asset"];

    if($eth1Array[1].StartsWith($publicSubnetPrefix)) {
        $publicVmBusId = $eth1Array[0];
    } else {
        $privateVmBusId = $eth1Array[0];
    }

    if($eth2Array[1].StartsWith($privateSubnetPrefix)) {
        $privateVmBusId = $eth2Array[0];
    } else {
        $publicVmBusId = $eth2Array[0];
    }

    return @{publicVmBusId=$publicVmBusId;privateVmBusId=$privateVmBusId;assetId=$assetId}
}

<#
    .SYNOPSIS
    Produce the gatewayIP based on the subnet value, since this subnet is always 24, and the default of gateway ip is X.X.X.1
#>
Function Get-SubnetGatewayIp
{
    [cmdletbinding()]
    Param 
    (
        [Parameter()] [string] $subnet
    )

    $splitIp = $subnet.split("/")[0].split(".")
    $splitIp[3] = "1"
    $gatewayIp = $splitIp -join "."

    return $gatewayIp
}

<#
	.SYNOPSIS
	Based on the IpAddress and the IpMask, produce the subnet in the format of cidr. 
#>
function Get-NetId {

    [CmdletBinding()]
    param (
      [Parameter()]
      [IpAddress]
      $IpAddress,
      [Parameter()]
      [IpAddress]
      $IpMask
    )
  
    [IpAddress]$NetIp = $IpAddress.Address -band $IpMask.Address
  
    [Int]$CIDR = (
      (-join (
        $IpMask.ToString().split('.') | 
          foreach {[convert]::ToString($_,2)} #convert each octet to binary
        ) #and join to one string
      ).ToCharArray() | where {$_ -eq '1'} #then only keep '1'
    ).Count
  
    return $NetIp.ToString() + '/' + $CIDR
}

<#
    .SYNOPSIS
    Make request to the ase portal to get the port1, port2 and port3 network settings, based on the network settings 
    and the vmbusId extension returned info, produce the vmbusId for Satcom, Wan, Lan, and also subnet and gatewayIp info 
    from Satcom, Wan and Lan.
#>
Function Get-EdgeNetworkInfo
{
    [cmdletbinding()]
    Param 
    (
        [object]
        [parameter(mandatory=$true)]
        $vmBusIdInput,
        [Parameter(Mandatory)]
        [ValidateSet("commercial", "government")]
        $cloudType,
        [Parameter(Mandatory)]
        $tenantID,
        [Parameter(Mandatory)]
        $subscriptionID,
        [Parameter(Mandatory)]
        $resourceGroupName,
        [Parameter(Mandatory)]
        $ASEResourceName,
        [Parameter(Mandatory)]
        $IncludesAsusRouter,
        [string]
        $SecondarySubnetMask,
        [string]
        $SecondaryGateway
    )

    $endpointInfo =  Get-ManagementAPIEndpoint -cloudType $cloudType
    $baseURI = $endpointInfo.baseURI
    $apiVer = "?api-version=2023-02-01"

    $resourceId = "/subscriptions/" + $subscriptionID + "/resourceGroups/" + $resourceGroupName + "/providers/Microsoft.DataBoxEdge/DataBoxEdgeDevices/" + $ASEResourceName + "/networkSettings/default"

    $bearerToken = Get-AzBearerToken -cloudType $cloudType -subscriptionID $subscriptionID -tenantID $tenantID
    $headers = New-Object "System.Collections.Generic.Dictionary[[String],[String]]"
    $headers.Add("Authorization", "Bearer $bearerToken")
    $headers.Add("Content-Type", "application/json")

    $response = Invoke-WebRequest "$baseURI/$resourceId/$apiVer" -Method "GET" -Headers $headers

    $content = $response.Content
    $object = $content | ConvertFrom-Json

    $adapters = $object.properties.networkAdapters;

    $lanAdapter = $adapters | Where-Object {$_.networkAdapterName -eq "Port3"}
    $lanGatewayIp = [IPAddress]$lanAdapter.ipv4Configuration.gateway;
    $lanSubnetMask = [IPAddress]$lanAdapter.ipv4Configuration.subnet;
    $lanNet = Get-NetId -IpAddress $lanGatewayIp -IpMask $lanSubnetMask
    $lanSubnet = [IPAddress]($lanGatewayIp.Address -band $lanSubnetMask.Address)

    # When we don't have an ASUS router, none of the values for SATCOM and SECONDARY exist
    if ($IncludesAsusRouter) {

        $satcomAdapter = $adapters | Where-Object {$_.networkAdapterName -eq "Port1"}
        $satcomGatewayIp = [IPAddress]$satcomAdapter.ipv4Configuration.gateway;
        $satcomSubnetMask = [IPAddress]$satcomAdapter.ipv4Configuration.subnet;
        $satcomNet = Get-NetId -IpAddress $satcomGatewayIp -IpMask $satcomSubnetMask
        $satcomSubnet = [IPAddress]($satcomGatewayIp.Address -band $satcomSubnetMask.Address)

        $wanAdapter = $adapters | Where-Object {$_.networkAdapterName -eq "Port2"}
        $wanGatewayIp = [IPAddress]$wanAdapter.ipv4Configuration.gateway;
        $wanSubnetMask = [IPAddress]$wanAdapter.ipv4Configuration.subnet;
        $wanNet = Get-NetId -IpAddress $wanGatewayIp -IpMask $wanSubnetMask
        $wanSubnet = [IPAddress]($wanGatewayIp.Address -band $wanSubnetMask.Address)

    }
    else {

        $satcomGatewayIp = [IPAddress]"100.64.0.1"
        $satcomSubnetMask = [IPAddress]"255.192.0.0"
        $satcomNet = Get-NetId -IpAddress $satcomGatewayIp -IpMask $satcomSubnetMask
        $satcomSubnet = [IPAddress]($satcomGatewayIp.Address -band $satcomSubnetMask.Address)
        
        $wanGatewayIp = [IPAddress]$SecondaryGateway
        $wanSubnetMask = [IPAddress]$SecondarySubnetMask
        $wanNet = Get-NetId -IpAddress $wanGatewayIp -IpMask $wanSubnetMask
        $wanSubnet = [IPAddress]($wanGatewayIp.Address -band $wanSubnetMask.Address)

    }

    foreach($value in $vmBusIdInput.Values) 
    {
        $array = $value.split(" ");
        if($array.length -eq 2) 
        {
            $nicIp = [IPAddress] $array[1];
            
            if($satcomSubnet.Address -eq ($nicIp.Address -band $satcomSubnetMask.Address)) 
            {
                $satcomVmBusId = $array[0];
                $satcomNicIp = $array[1];
            } elseif ($wanSubnet.Address -eq ($nicIp.Address -band $wanSubnetMask.Address)) 
            {
                $wanVmBusId = $array[0];
                $wanNicIp = $array[1];
            } elseif ($lanSubnet.Address -eq ($nicIp.Address -band $lanSubnetMask.Address)) 
            {
                $lanVmBusId = $array[0];
                $lanNicIp = $array[1];
            }
        }
    }

    $assetId = $vmBusIdInput["asset"]

    return @{
        satcomGatewayIp=$satcomGatewayIp.IPAddressToString; `
        satcomSubnet=$satcomNet; `
        satcomVmBusId=$satcomVmBusId; `
        satcomNicIp=$satcomNicIp; `
        wanGatewayIp=$wanGatewayIp.IPAddressToString; `
        wanSubnet=$wanNet; `
        wanVmBusId=$wanVmBusId; `
        wanNicIp=$wanNicIp; `
        lanGatewayIp=$lanGatewayIp.IPAddressToString; `
        lanSubnet=$lanNet; `
        lanVmBusId=$lanVmBusId; `
        lanNicIp=$lanNicIp; `
        assetId=$assetId; `
    }
    
}

<#
	.SYNOPSIS
	Updates role assignment on a specific Azure resource based on parameters.
#>
function Update-RoleAssignment() {

	param(
		[Parameter(Mandatory)]
		$ProviderObjectId,
		[Parameter(Mandatory)]
		$RoleDefinitionName,
		[Parameter(Mandatory)]
		$Scope,
        [switch]
        $IgnoreErrors

	)

	try {
        # There is a case where we want to ignore errors (ASE role assignment)
        if ($IgnoreErrors) {
            $suppressOutput = New-AzRoleAssignment -ObjectId $ProviderObjectId `
                -RoleDefinitionName $RoleDefinitionName `
                -Scope $Scope `
                -ErrorAction SilentlyContinue
        }
        else {            
            $suppressOutput = New-AzRoleAssignment -ObjectId $ProviderObjectId `
                -RoleDefinitionName $RoleDefinitionName `
                -Scope $Scope `
                -ErrorAction Stop
        }
	}
	catch {
		if (-not $_.Exception.Message.Contains("'Conflict'")) {
			throw $_
		}
	}
}

<#
    .SYNOPSIS
    Determines which set of Orbital RP IPs to use based on cloud type.
#>
function Get-OrbitalRPPublicIPs() {

    param(
        [Parameter(Mandatory)]
        [string]
        $cloudType
    )

    if ($cloudType -eq "government") {
        return '"52.126.33.3","52.126.34.241","20.141.126.107","20.141.126.82","52.245.225.186","20.141.128.229"'
    }
    else {
        return '"20.26.51.176","20.26.51.80","20.102.21.138","20.102.21.162","20.227.27.171","20.227.27.140"'
    }

}

<#
    .SYNOPSIS
    Determines which VPN Gateway SKU to use based on region
#>
function Get-VPNGatewaySKU() {
    
    param(
        [Parameter(Mandatory)]
        [string]
        $targetRegion,
        [Parameter(Mandatory)]
        [string]
        $cloudType        
    )

    # Availability zones are only available in Virginia in FF, and it must be set to Az if VA is the target.
    # All regions in commercial are Az enabled
    if ($targetRegion -eq "usgovvirginia" -or $targetRegion -eq "usgov virginia" -or $cloudType -eq "commercial") {                
        return "VpnGw2Az"
    }
    else {
        return "VpnGw2"
    }

}

<#
    .SYNOPSIS
    Prompts the user with a Y/N question and processes their response
#>
function Receive-UserConfirmation() {

    param(
        [Parameter(Mandatory)]
        [string]
        $Prompt,
        [string]
        $DeclineMessage = "",
        [switch]
        $IsTerminating
    )

    $choices = New-Object Collections.ObjectModel.Collection[Management.Automation.Host.ChoiceDescription]
    $choices.Add((New-Object Management.Automation.Host.ChoiceDescription -ArgumentList '&Yes'))
    $choices.Add((New-Object Management.Automation.Host.ChoiceDescription -ArgumentList '&No'))

    $decision = $Host.UI.PromptForChoice("", $Prompt, $choices, 1)
    
    if ($decision -ne 0) {

        if ($IsTerminating) {
            throw $DeclineMessage
        }

        Write-Host -ForegroundColor Yellow $DeclineMessage
        return $false

    }

    return $true

}

<#
    .SYNOPSIS
    Logs into the Conductor and returns a login token
#>
function Get-ConductorToken() {

    param (
        [Parameter(Mandatory)]
        [string]
        $PublicIpAddress,
        [Parameter(Mandatory)]
        [string]
        $Username,
        [Parameter(Mandatory)]
        [string]
        $Key,
        [Parameter()]
        [int]
        $RetryPeriodSeconds = 10,
        [Parameter()]
        [int]
        $MaxTries = 3
    )
    
    $Tries = 1
    $conductorLogin = "https://" + $PublicIpAddress + "/api/v1/login"

    $requestBody = @{
        "username" = $Username;
        "password" = $Key
    };

    for($Tries; $Tries -le $MaxTries; $Tries++) { 

        try {
            # The conductor does not have an official CA authority when freshly spun up, so we need to SkipCertificateCheck for any of the API calls to work properly.
            $response = Invoke-RestMethod -Uri $conductorLogin -Method POST -Body ($RequestBody | ConvertTo-Json) -ContentType "application/json" -SkipCertificateCheck
            return $response.token
        }
        catch [System.Net.WebException] {
            $ex = $_
            if($Tries -lt $MaxTries) {
                Start-Sleep -Seconds $RetryPeriodSeconds
            }
            else {                
                Write-Error ("Tried to login conductor '{0}' {1}-times and failed" -f $conductorLogin, $tries);
                Write-Error "Status Code: " $ex.Exception.Response.StatusCode
                throw $ex
            }
        }
    }
}

<#
    .SYNOPSIS
    Calls the Juniper COMMIT API call for apply candidate configurations.
#>
function Update-JuniperConfiguration() {

    param(
        [Parameter(Mandatory)]
        [string]
        $ConductorPublicIP,
        [Parameter(Mandatory)]
        $Headers
    )
    
    $commitURI = "https://$ConductorPublicIP/api/v1/config/commit"

    $commitBody = @{
        "distributed" = $false;
        "warningsAsErrors" = $false
    }

    $suppressOutput = Invoke-RestMethod -Uri $commitURI -Method POST -Headers $headers -Body ($commitBody | ConvertTo-Json) -SkipCertificateCheck

}

<#
    .SYNOPSIS
    Updates a customers Juniper configuration to associate an asset ID to newly provisioned router(s).
#>
function Update-RouterAssetID() {

    param(
        [Parameter(Mandatory)]
        [string]
        $ConductorBearerToken,
        [Parameter(Mandatory)]
        [string]
        $ConductorPublicIP,
        [Parameter(Mandatory)]
        [string]
        $EdgeSSRName,
        [Parameter(Mandatory)]
        [string]
        $EdgeSSRAssetID,
        [Parameter(Mandatory)]
        [string]
        $CloudSSRName,
        [Parameter(Mandatory)]
        [string]
        $CloudSSRAssetID        
    )

    $headers = New-Object "System.Collections.Generic.Dictionary[[String],[String]]"
    $headers.Add("Authorization", "Bearer $ConductorBearerToken")
    $headers.Add("Content-Type", "application/json")

    $edgeNodeName = $EdgeSSRName + "_node"
    $cloudNodeName = $CloudSSRName + "_node"

    $edgeURI = "https://$ConductorPublicIP/api/v1/config/running/authority/router/$EdgeSSRName/node/$edgeNodeName"
    $cloudURI = "https://$ConductorPublicIP/api/v1/config/running/authority/router/$CloudSSRName/node/$cloudNodeName"

    try {

        # Retrieve node configuration from Juniper. Call will fail if config has yet to be pushed
        $edgeNode = Invoke-RestMethod -Uri $edgeURI -Method GET -Headers $headers -SkipCertificateCheck
        $cloudNode = Invoke-RestMethod -Uri $cloudURI -Method GET -Headers $headers -SkipCertificateCheck

    }
    catch {
        # Failure here is not critical, and we will eventually re-try
        return $false
    }

    # Update ASSET ID values
    $edgeNode.'asset-id' = $EdgeSSRAssetID
    $edgeNode.assetId = $EdgeSSRAssetID
    $edgeNode.psobject.properties.remove('name')
    
    $cloudNode.'asset-id' = $CloudSSRAssetID
    $cloudNode.assetId = $CloudSSRAssetID
    $cloudNode.psobject.properties.remove('name')

    try {

        # Update node configuration w/ the new ASSET ID values
        $edgeNode = Invoke-RestMethod -Uri $edgeURI -Method PATCH -Headers $headers -Body ($edgeNode | ConvertTo-Json) -SkipCertificateCheck
        $cloudNode = Invoke-RestMethod -Uri $cloudURI -Method PATCH -Headers $headers -Body ($cloudNode | ConvertTo-Json) -SkipCertificateCheck
        Update-JuniperConfiguration -ConductorPublicIP $ConductorPublicIP -Headers $headers

    }
    catch {
        
        return $false
    }

    return $true

}

<#
    .SYNOPSIS
    Updates the AOCAAgent tenant on an Edge SSR to include 
#>
function Update-ASEHostIPTenant() {

    param(
        [Parameter(Mandatory)]
        [string]
        $ConductorBearerToken,
        [Parameter(Mandatory)]
        [string]
        $ConductorPublicIP,
        [Parameter(Mandatory)]
        [string]
        $EdgeSSRName,
        [Parameter(Mandatory)]
        [string]
        $ASEHostOSIP
    )

    $headers = New-Object "System.Collections.Generic.Dictionary[[String],[String]]"
    $headers.Add("Authorization", "Bearer $ConductorBearerToken")
    $headers.Add("Content-Type", "application/json")

    $edgeNodeName = $EdgeSSRName + "_node"
    $edgeLanDevName = "edgelan_lan"
    $edgeLanNicName = "edgelan_nic"
    $agentTenant = "AOCAAgent"

    $tenantURI = "https://$ConductorPublicIP/api/v1/config/running/authority/router/$EdgeSSRName/node/$edgeNodeName/device-interface/$edgeLanDevName/network-interface/$edgeLanNicName/tenant-prefixes/$agentTenant"

    try {

        # Retrieve tenant prefix configuration from Juniper.
        $agentTenant = Invoke-RestMethod -Uri $tenantURI -Method GET -Headers $headers -SkipCertificateCheck

    }
    catch {
        return $false
    }

    # Juniper requires CIDR format
    $ASEHostOSIPCIDR = $ASEHostOSIP + "/32"

    # Update ASSET ID values
    $agentTenant.'source-address' += $ASEHostOSIPCIDR
    $agentTenant.sourceAddress += $ASEHostOSIPCIDR
    $agentTenant.psobject.properties.remove('tenant')

    try {

        # Update node configuration w/ the new ASSET ID values
        $agentTenant = Invoke-RestMethod -Uri $tenantURI -Method PATCH -Headers $headers -Body ($agentTenant | ConvertTo-Json) -SkipCertificateCheck
        Update-JuniperConfiguration -ConductorPublicIP $ConductorPublicIP -Headers $headers

    }
    catch {        
        return $false
    }

    return $true

}