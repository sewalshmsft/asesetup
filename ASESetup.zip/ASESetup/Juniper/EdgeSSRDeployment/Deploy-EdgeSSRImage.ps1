#-------------------------------------------------------------------------------------
# <copyright file="Deploy-EdgeSSRImage.ps1" company="Microsoft">
#     Copyright (c) Microsoft Corporation. All rights reserved.
# </copyright>
#-------------------------------------------------------------------------------------

[CmdletBinding()]
param(
    [Parameter(Mandatory = $true)]
    [string]
    $ASEResourceID,
    [Parameter(Mandatory = $true)]
    [string]
    $JuniperImageSASURI,
    [ValidateScript({
		if($_ -notmatch "(\.template)$"){
			throw "The file specified in the path argument must be of type template"
		}
		return $true 
	})]	
    [Parameter(Mandatory = $true)]
    [string]
    $SSRImageTemplatePath,
    [parameter(mandatory = $true)]
    [ValidateSet("commercial","government")]
    [string]
    $CloudEnvironment,
    [parameter(mandatory = $true)]
    [string]
    $ASETenantID
)

$resourceFieldArray = $ASEResourceID.split("/");
$ASESubscriptionID = $resourceFieldArray[2]

$bearerToken = Get-AzBearerToken -cloudType $CloudEnvironment `
    -subscriptionID $ASESubscriptionID `
    -tenantID $ASETenantID

$targetASE = Get-AzResource -ResourceId $ASEResourceID

$linkedSubId = $targetASE.Properties.edgeProfile.subscription.id
$guid = New-Guid
$deploymentName = "SSR-" + $guid.Guid.Split("-")[0]
$deploymentNameAndTimestamp = "SSRImageDeploy-imagedeployment-" + (Get-Date -f yyyyMddHHmm)
$cleanupImageName = "cleanup" + $deploymentName
$containerName = "container" + (Get-Date -f yyyyMddHHmm)
$deploymentURI = "$linkedSubId/linkedProviders/Microsoft.Resources/deployments/$deploymentName"

$endpointInfo = Get-ManagementAPIEndpoint -cloudType $CloudEnvironment
$baseURI = $endpointInfo.baseURI
$apiVer = $endpointInfo.apiVer

$deploymentTemplate = Get-Content -Path $SSRImageTemplatePath -Raw
$deploymentTemplate = $deploymentTemplate `
    -replace "___deploymentNameAndTimestamp___", $deploymentNameAndTimestamp `
    -replace "___vhdBlobUri___", $JuniperImageSASURI `
    -replace "___containername___", $containerName `
    -replace "___ingestionJobName___", $deploymentName `
    -replace "___deploymentName___", $deploymentName `
    -replace "___cleanUpImageName___", $cleanupImageName

$headers = New-Object "System.Collections.Generic.Dictionary[[String],[String]]"
$headers.Add("Authorization", "Bearer $bearerToken")
$headers.Add("Content-Type", "application/json")


$imageDeployResponse = Invoke-ASEWebRequest -uri "$baseURI/$deploymentURI/$apiVer" `
    -method 'PUT' `
    -headers $headers `
    -body $deploymentTemplate

# TODO ecaraballo: location of async op URI is different in prod vs. fairfax, this needs to be more dynamic
$imageDeployRawContent = $imageDeployResponse.RawContent
$rawContentArr = ($imageDeployRawContent -split '\r?\n').Trim()
$asyncOpURI = $rawContentArr[3].Substring($rawContentArr[3].IndexOf("https"))

Write-Host -ForegroundColor Green "Successfully sent image creation request to the ASE. Checking status on operation in 60 seconds: $asyncOpURI"
Start-Sleep -s 60

Watch-AsyncOperation `
    -asyncOpURI $asyncOpURI `
    -resourceType "Image" `
    -headers $headers

return $deploymentName