#-------------------------------------------------------------------------------------
# <copyright file="Deploy-EdgeSSRVM.ps1" company="Microsoft">
#     Copyright (c) Microsoft Corporation. All rights reserved.
# </copyright>
#-------------------------------------------------------------------------------------

[CmdletBinding()]
param(
    [Parameter(Mandatory = $true)]
    [string]
    $ASEResourceID,
    [Parameter(Mandatory = $true)]
    [string]
    $JuniperImageName,
    [Parameter(Mandatory = $true)]
    [string]
    $SSRSSHPublicKey,
    [ValidateScript({
        if(-Not ($_ -match[IPAddress]$_)) {
            throw "Please enter a LAN IP address of a valid format."
        }
        return $true
    })]
    [Parameter(Mandatory = $true)]    
    [IPAddress]
    $SSRLanGatewayIP,
    [ValidateScript({
        if(-Not ($_ -match[IPAddress]$_)) {
            throw "Please enter an IP address of a valid format."
        }
        return $true
    })]
    [Parameter(Mandatory = $true)]    
    [string]
    $SSRLanNetmask,
    [ValidateScript({
        if($_ -notmatch "(\.template)$"){
            throw "The file specified in the path argument must be of type template"
        }
        return $true 
    })] 
    [Parameter(Mandatory = $true)]
    [string]
    $SSRVMTemplatePath,
    [parameter(mandatory)]
    [ValidateSet("commercial","government")]
    [string]
    $CloudEnvironment,
    [ValidateScript({
        if($_ -notmatch "(\.yml)$"){
            throw "The file specified in the path argument must be of type yml."
        }
        return $true 
    })] 
    [Parameter(Mandatory = $true)]
    [string]
    $CloudInitScriptPath,
    [ValidateScript({
        if(-Not ($_ -match[IPAddress]$_)) {
            throw "Please enter a Conductor IP address of a valid format."
        }
        return $true
    })]
    [Parameter(Mandatory = $true)]
    [IPAddress]
    $ConductorPublicIP,
    [Parameter(Mandatory = $true)]
    [string]
    $ASETenantID
)

$resourceFieldArray = $ASEResourceID.split("/");
$ASESubscriptionID = $resourceFieldArray[2]

$bearerToken = Get-AzBearerToken -cloudType $CloudEnvironment `
    -subscriptionID $ASESubscriptionID `
    -tenantID $ASETenantID

$targetASE = Get-AzResource -ResourceId $ASEResourceID

# TODO ecaraballo: Add more error handling for non-happy path
# ASE resource deployment needs to target the linked subscription
$linkedSubId = $targetASE.Properties.edgeProfile.subscription.id
$guid = New-Guid
$deploymentName = "EdgeSSR-" + $guid.Guid.Split("-")[0]
$deploymentNameAndTimestamp = "SSRVMDeploy-vmdeployment-" + (Get-Date -f yyyyMddHHmm)
$vmDeploymentURI = "$linkedSubId/linkedProviders/Microsoft.Resources/deployments/$deploymentName"

$endpointInfo = Get-ManagementAPIEndpoint -cloudType $CloudEnvironment
$baseURI = $endpointInfo.baseURI
$apiVer = $endpointInfo.apiVer

# Format the cloud-init file before adding to VM template
$cloudInitScript = Remove-ScriptSpecialCharacters -scriptPath $CloudInitScriptPath
$formattedCIScript = $cloudInitScript -join "\n" `
    -replace '"', '\"' `
    -replace "___AssetID___", $deploymentName `
    -replace "___ConductorIP___", $ConductorPublicIP.IPAddressToString `
    -replace "___LanNICIP___", $SSRLanGatewayIP `
    -replace "___LanNetmask___", $SSRLanNetmask

# Escape any escape characters
$SSRSSHPublicKey = $SSRSSHPublicKey -replace '\\', '\\'

# VM Deployment
$vmDeploymentTemplate = Get-Content -Path $SSRVMTemplatePath -Raw
$vmDeploymentTemplate = $vmDeploymentTemplate `
    -replace "___deploymentName___", $deploymentName `
    -replace "___deploymentNameAndTimestamp___", $deploymentNameAndTimestamp `
    -replace "___imageName___", $JuniperImageName `
    -replace "___sshKeyData___", $SSRSSHPublicKey `
    -replace "___LANGateway___", $SSRLanGatewayIP.IPAddressToString `
    -replace "___cloudInitScript___", $formattedCIScript

$headers = New-Object "System.Collections.Generic.Dictionary[[String],[String]]"
$headers.Add("Authorization", "Bearer $bearerToken")
$headers.Add("Content-Type", "application/json")

$vmDeployResponse = Invoke-ASEWebRequest -uri "$baseURI/$vmDeploymentURI/$apiVer" `
    -method 'PUT' `
    -headers $headers `
    -body $vmDeploymentTemplate

$vmDeployRawContent = $vmDeployResponse.RawContent
$rawContentArr = ($vmDeployRawContent -split '\r?\n').Trim()
$asyncOpURI = $rawContentArr[3].Substring($rawContentArr[3].IndexOf("https"))

Write-Host -ForegroundColor Green "Successfully sent VM creation request to the ASE. Checking status on operation: $asyncOpURI"
Watch-AsyncOperation `
    -asyncOpURI $asyncOpURI `
    -resourceType "Virtual Machine" `
    -headers $headers

return $deploymentName