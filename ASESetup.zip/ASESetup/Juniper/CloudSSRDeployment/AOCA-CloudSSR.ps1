#-------------------------------------------------------------------------------------
# <copyright file="AOCA-CloudSSR.ps1" company="Microsoft">
#     Copyright (c) Microsoft Corporation. All rights reserved.
# </copyright>
#-------------------------------------------------------------------------------------

param (
    [parameter(mandatory)]
    [PSObject]
    $dayZeroMappings,
    [ValidateScript({
		if($_ -notmatch "(\.json)$"){
			throw "The file specified in the path argument must be of type template"
		}
		return $true 
	})]	
    [parameter(mandatory)] 
    [string] 
    $cloudSSRTemplatePath,
    [parameter(mandatory)] 
    [string] 
    $conductorPublicIp,
    [parameter(mandatory)] 
    [string] 
    $virtualNetworkName
)

$newline = [System.Environment]::NewLine

$dedicatedASELanSubnetMask = $dayZeroMappings.NetworkingInformation.DedicatedASELanSubnetMask
$dedicatedASELanIP = $dayZeroMappings.NetworkingInformation.DedicatedASELanIP

$cidr = (Convert-Subnetmask -Mask $dedicatedASELanSubnetMask).CIDR
$subnet = ([IPAddress] (([IPAddress] $dedicatedASELanIP).Address -band ([IPAddress] $dedicatedASELanSubnetMask).Address)).ToString()

$edgeSSRSubnetPrefix = $subnet + "/" + $cidr

$localPublicIpAddress = (Invoke-WebRequest -uri "https://ifconfig.me/ip").Content

$cloudEnvironment = $dayZeroMappings.AzureEnvironmentOptions.CloudEnvironment
$subscriptionId = $dayZeroMappings.AzureInformation.TargetSubscriptionID
$tenantId = $dayZeroMappings.AzureInformation.TargetTenantID
$resourceGroupName = $dayZeroMappings.AzureInformation.TargetResourceGroupName

$tokenSuppress = Get-AzBearerToken -cloudType $cloudEnvironment `
    -subscriptionID $subscriptionId `
    -tenantID $tenantId

$guid = New-Guid

$cloudSSRName = "CloudSSR-" + $guid.Guid.Split("-")[0]

$mgmtSubnet = "/subscriptions/$subscriptionId/resourceGroups/$resourceGroupName/providers/Microsoft.Network/virtualNetworks/$virtualNetworkName/subnets/MGMT"

$shellScriptPath = $dayZeroMappings.DayZeroFilePaths.CloudShellScriptPath
$cloudInitScriptPath =  $dayZeroMappings.DayZeroFilePaths.CloudSSRCloudInitFilePath

$script = Get-Content $shellScriptPath -Raw
$deploymentNameAndTimestamp = "SSRVMDeploy-vmdeployment-" + (Get-Date -f yyyyMddHHmm)

$cloudInitScript = Remove-ScriptSpecialCharacters -scriptPath $cloudInitScriptPath
$formattedCIScript = $cloudInitScript -join "\n" `
    -replace '"', '\"' `
    -replace "___ConductorIP___", $conductorPublicIp `
    -replace "___CloudSSRAssetID___", $cloudSSRName

$WANSubnetIPAddressSpace = $dayZeroMappings.AzureInformation.AzurevNetWANSubnetAddressSpace
$LANSubnetIPAddressSpace = $dayZeroMappings.AzureInformation.AzurevNetLANSubnetAddressSpace

# Ensure the vnet ranges are valid
$parseErrors = ""

$parseErrors = (Test-CIDRNotation -cidrString $WANSubnetIPAddressSpace -errVar $parseErrors -varName "dayZeroMappings.AzureInformation.AzurevNetWANSubnetAddressSpace")
$parseErrors = (Test-CIDRNotation -cidrString $LANSubnetIPAddressSpace -errVar $parseErrors -varName "dayZeroMappings.AzureInformation.AzurevNetLANSubnetAddressSpace")

if ($parseErrors.length -gt 0) {
	throw "Something went wrong validating the format of the provided IP addresses: $newline $newline$parseErrors"
}

(Get-Content $cloudSSRTemplatePath) `
    -Replace('___deploymentNameAndTimestamp___', $deploymentNameAndTimestamp) `
    -replace "___cloudInitScript___", $formattedCIScript `
    | Set-Content './cloudSSR-template-tmp.json'

try {

    $location =  $dayZeroMappings.AzureInformation.TargetRegion
    $sshPublicKey =  $dayZeroMappings.JuniperInformation.CloudSSRSSHPublicKey
    $ssrSKUName =  $dayZeroMappings.JuniperInformation.CloudSSROfferSKUName
    
    $output = New-AzResourceGroupDeployment -ResourceGroupName $resourceGroupName `
        -TemplateFile './cloudSSR-template-tmp.json' `
        -cloudSSRName $cloudSSRName `
        -location $location `
        -virtualNetworkName $virtualNetworkName `
        -deploymentNameAndTimestamp $deploymentNameAndTimestamp `
        -adminAllowedCidr $localPublicIpAddress `
        -conductorPrimaryControlIP $conductorPublicIp `
        -managementSubnetExternalId $mgmtSubnet `
        -adminPublicKeyData $sshPublicKey `
        -cloudSSRSKUName $ssrSKUName `
        -WANSubnetIPAddressSpace $WANSubnetIPAddressSpace `
        -LANSubnetIPAddressSpace $LANSubnetIPAddressSpace `
        -Verbose `
        -ErrorAction Stop

    $lanNicPrivateIpAddress = $output.Outputs["lanNicPrivateIpAddress"].Value
    $routeTableName = $output.Outputs["routeTableName"].Value

    # Adding a 30s sleep here as 6.2.3 takes a while to start up.
    Write-Host -ForegroundColor Yellow "Waiting 30 seconds for 128T software initialization..."
    Start-Sleep -Seconds 30
    
    $customScriptExtensionTemplatePath =  $dayZeroMappings.DayZeroFilePaths.CloudSSRCustomScriptTemplatePath

    $suppressOutput = New-AzResourceGroupDeployment -ResourceGroupName $resourceGroupName `
        -TemplateFile $customScriptExtensionTemplatePath `
        -cloudSSRName $cloudSSRName `
        -location $location `
        -script $script

    $routesTemplatePath = $dayZeroMappings.DayZeroFilePaths.CloudSSRTRoutesTemplatePath

    $suppressOutput = New-AzResourceGroupDeployment -ResourceGroupName $resourceGroupName -TemplateFile $routesTemplatePath `
        -routeTableName $routeTableName `
        -lanPrivateIpAddress $lanNicPrivateIpAddress `
        -addressPrefix $edgeSSRSubnetPrefix `
        -Verbose `
        -ErrorAction Stop

    $extension = Get-AzVMExtension -ResourceGroupName $resourceGroupName -VMName $cloudSSRName -Name "retrieveVMBusId" -Status
}
catch {
    # If we run into any errors provisioning resources, we'll delete any intermediate resources that may have been created.
    Remove-CloudSSRResources -resourceGroupName $resourceGroupName -cloudSSRName $cloudSSRName -virtualNetworkName $virtualNetworkName
    Rename-Item -Path './cloudSSR-template-tmp.json' -NewName "cloudSSR-template-tmp.$(Get-Date -f yyyyMddHHmm).json"
    throw
}
finally {
    Remove-Item -Path './cloudSSR-template-tmp.json' -ErrorAction SilentlyContinue
}

$message = $extension.Statuses.Message

$outStart = $message.IndexOf('[stdout]')
$errStart = $message.IndexOf('[stderr]')

if ($outStart -eq -1 -or $errStart -eq -1) {
    Write-Host -ForegroundColor Red "Custom Script Extension result is not in an expected format: $message"
    exit
}

# Actual output is located between [stdout] and [stderr] tokens
$vmBusInfoOutput = $message.Substring($outStart + 9, $errStart - $outStart - 9).Trim()

$outArrStart = $vmBusInfoOutput.IndexOf('(')
$newLine = [System.Environment]::NewLine

try {    
    $vmBusIdOutArr = $vmBusInfoOutput.Substring($outArrStart) `
        -replace '[()'']', '' `
        -replace '[\[\]]', '"' `
        -replace '" "', "`" $newLine `"" `
        -replace '"', "" `
        | ConvertFrom-StringData
}
catch {
    # If something goes wrong during parsing, then the output of CSE was not as expected
    Write-Host -ForegroundColor Red "Something went wrong when parsing the output of Custom Script Extension: $message"
    exit
}

$privateNicName = $cloudSSRName + "-private"
$cloudSSRPrivateNic = Get-AzNetworkInterface -Name $privateNicName -ResourceGroupName $resourceGroupName
$PrivateNicIpConfig = Get-AzNetworkInterfaceIpConfig -NetworkInterface $cloudSSRPrivateNic
$cloudSSRPrivateNicPrivateIp = $PrivateNicIpConfig.PrivateIpAddress

$publicNicName = $cloudSSRName + "-public"
$cloudSSRPublicNic = Get-AzNetworkInterface -Name $publicNicName -ResourceGroupName $resourceGroupName
$publicNicIpConfig = Get-AzNetworkInterfaceIpConfig -NetworkInterface $cloudSSRPublicNic
$cloudSSRPublicNicPrivateIp = $publicNicIpConfig.PrivateIpAddress

$publicNicPublicIpConfig = Get-AzPublicIpAddress -Name $publicNicName -ResourceGroupName $resourceGroupName
$cloudSSRPublicNicPublicIp = $publicNicPublicIpConfig.IpAddress

$virtualNetwork =  Get-AzVirtualNetwork -ResourceGroup $resourceGroupName -Name $virtualNetworkName
$publicSubnet = (Get-AzVirtualNetworkSubnetConfig -Name "WAN" -VirtualNetwork $virtualNetwork).AddressPrefix
$privateSubnet = (Get-AzVirtualNetworkSubnetConfig -Name "LAN" -VirtualNetwork $virtualNetwork).AddressPrefix

$publicGatewayIp = Get-SubnetGatewayIp -subnet $publicSubnet
$privatecGatewayIp = Get-SubnetGatewayIp -subnet $privateSubnet

$publicSubnetPrefix = $publicSubnet[0].Split(".")[0..2] -join "."
$privateSubnetPrefix = $privateSubnet[0].Split(".")[0..2] -join "."

$VmBusIdInfo = Get-VMBusIdInfo -vmBusIdInput $vmBusIdOutArr -publicSubnetPrefix $publicSubnetPrefix -privateSubnetPrefix $privateSubnetPrefix
$privateVmBusId = $VmBusIdInfo.privateVmBusId
$publicVmBusId = $VmBusIdInfo.publicVmBusId
$assetId = $VmBusIdInfo.assetId

# This data will eventually be passed to AOCA resource creation
return @{
    cloudSSRName=$cloudSSRName; `
    cloudSSRPrivateNicPrivateIp=$cloudSSRPrivateNicPrivateIp; `
    cloudSSRPublicNicPrivateIp=$cloudSSRPublicNicPrivateIp; `
    cloudSSRPublicNicPublicIp=$cloudSSRPublicNicPublicIp; `
    publicSubnet=$publicSubnet[0]; `
    privateSubnet=$privateSubnet[0]; `
    publicGatewayIp=$publicGatewayIp; `
    privatecGatewayIp=$privatecGatewayIp; `
    privateVmBusId=$privateVmBusId; `
    publicVmBusId=$publicVmBusId; `
    cloudSsrAssetId=$assetId; `
}
