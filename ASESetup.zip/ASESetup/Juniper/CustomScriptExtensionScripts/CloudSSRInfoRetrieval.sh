# !/usr/bin/env bash
# -------------------------------------------------------------------------------------
# <copyright file="CloudSSRInfoRetrieval.sh" company="Microsoft">
#     Copyright (c) Microsoft Corporation. All rights reserved.
# </copyright>
# -------------------------------------------------------------------------------------

set -eou pipefail

# Save DPDK into a file
dpdk-devbind.py --status-dev net >/home/azureuser/dpdkout.txt

# readarray turns the contents of a file into an array
readarray -t dpdk_arr </home/azureuser/dpdkout.txt

# cleanup
rm /home/azureuser/dpdkout.txt

declare -A res_arr
match_value="if=eth"

for outline in "${!dpdk_arr[@]}"
    # The matched lines contain the VMBUS ID for each iface
    do if [[ "${dpdk_arr[$outline]}" =~ $match_value ]]
        then vmbus_entry=${dpdk_arr[$outline]}
        # First token is the VMBUS ID
        vmbus="${vmbus_entry%% *}"
        # Find the eth value
        for word in ${vmbus_entry}
            # We don't want eth0 as that is the primary NIC reserved for management, and there's no useful info in eth3, eth4 and eth5 in cloud ssr
            do if [[ $word =~ $match_value && ! $word =~ "eth0" && ! $word =~ "eth3" && ! $word =~ "eth4" && ! $word =~ "eth5" ]]
                then res_arr["${word#*=}"]="$vmbus"
            fi
        done
    fi
done

# For now, we will always assume 3 non-management interfaces
ifconfig eth1 >/home/azureuser/eth1.txt
ifconfig eth2 >/home/azureuser/eth2.txt

readarray -t eth1_arr </home/azureuser/eth1.txt
readarray -t eth2_arr </home/azureuser/eth2.txt

# cleanup
rm /home/azureuser/eth*

# IFCONFIG has a standard output for every interface, the second line is ALWAYS IPv4 info
res_arr["eth1"]="${res_arr['eth1']} $(echo "${eth1_arr[1]}" | grep -Pom 1 '[0-9.]{7,15}' | head -1)"
res_arr["eth2"]="${res_arr['eth2']} $(echo "${eth2_arr[1]}" | grep -Pom 1 '[0-9.]{7,15}' | head -1)"
res_arr["asset"]="$(cat /etc/salt/minion_id)"

declare -p res_arr

