#-------------------------------------------------------------------------------------
# <copyright file="Deploy-NoSdwanAOCAResources.ps1" company="Microsoft">
#     Copyright (c) Microsoft Corporation. All rights reserved.
# </copyright>
#-------------------------------------------------------------------------------------

<#
	.SYNOPSIS
	Creates all the required Azure Orbital Cloud Access resources needed to set up edge to 
	cloud connectivity.

	.DESCRIPTION
	Leverages various input files (described in the parameters section) to create an Azure
	resource deployment job that generates all the necessary AOCA resources to get edge to
	cloud connectivity up and running.

	! IMPORTANT !
	Please ensure that you've fully filled out the Resource template file, and that your
	PowerShell version is 7.0+.

	.PARAMETER dayZeroMappings
	Object that stores all of the values the customer provided in our input template

	.PARAMETER vpnGatewayResourceId
	Azure resource ID of the target VPN Gateway

	.PARAMETER vpnGatewayConnectionResourceId
	Azure resource ID of the target VPN Gateway connection

	.PARAMETER vpnGatewayPublicIpResourceId
	Azure resource ID of the target VPN Gateway public IP

	.PARAMETER edgeLanSubnetCidr
	Subnet of the ASE's LAN segment

	.PARAMETER AOCANoSdwanResourceJsonTemplateFilePath
	File path of the AOCA resources ARM template

	.PARAMETER IncludesAsusRouter
	Flag of whether or not this deployment includes an ASUS router
#>
[CmdletBinding()]
param(
	[parameter(mandatory)]
	[PSObject]
	$dayZeroMappings,
	[parameter(mandatory)]
	[string]
	$vpnGatewayResourceId,
	[parameter(mandatory)]
	[string]
	$vpnGatewayConnectionResourceId,
	[parameter(mandatory)]
	[string]
	$vpnGatewayPublicIpResourceId,
	[parameter(mandatory)]
	[string]
	$edgeLanSubnetCidr,
	[ValidateScript({
		if($_ -notmatch "(\.json)$"){
			throw "The file specified in the path argument must be of type json"
		}
		return $true 
	})]
	[Parameter(Mandatory=$true)]
	[string]
	$AOCANoSdwanResourceJsonTemplateFilePath,
    [parameter(Mandatory = $true)]
    [Boolean]
    $IncludesAsusRouter
)

if (-not [boolean]($dayZeroMappings.AzureInformation.AOCAResourcePrefix -match "^[a-z][a-z0-9-]{1,61}[a-z0-9]$")) {
    throw "Resource prefix '$($dayZeroMappings.AzureInformation.AOCAResourcePrefix)' can only include letters, numbers, and '-'."
}

$newline = [System.Environment]::NewLine

$tokenSuppress = Get-AzBearerToken -cloudType $dayZeroMappings.AzureEnvironmentOptions.CloudEnvironment `
	-subscriptionID $dayZeroMappings.AzureInformation.TargetSubscriptionID `
	-tenantID $dayZeroMappings.AzureInformation.TargetTenantID
	
$azureStackEdgeResourceID = $dayZeroMappings.AzureStackEdgeInformation.AzureStackEdgeResourceID

# Role assignment to Azure Orbital Resource Provider
$ProviderObjectId = (Get-AzADServicePrincipal -DisplayName "Azure Orbital Resource Provider").id

# RG of the ASE
$aseRgId = "/" + ($azureStackEdgeResourceID.split("/")[1..4] -Join "/")

# For below, conflict in the error means that the role already exists, which is good
try {
	Update-RoleAssignment -ProviderObjectId $ProviderObjectId `
		-RoleDefinitionName "Contributor" `
		-Scope $vpnGatewayResourceId 

	Update-RoleAssignment -ProviderObjectId $ProviderObjectId `
		-RoleDefinitionName "Contributor" `
		-Scope $vpnGatewayPublicIpResourceId

	Update-RoleAssignment -ProviderObjectId $ProviderObjectId `
		-RoleDefinitionName "Contributor" `
		-Scope $vpnGatewayConnectionResourceId

	Update-RoleAssignment -ProviderObjectId $ProviderObjectId `
		-RoleDefinitionName "Contributor" `
		-Scope $aseRgId `
		-IgnoreErrors
}
catch {
	throw $_
}

# Validate IP formatting
$parseErrors = ""

if ($IncludesAsusRouter) {
	$parseErrors = (Test-IPAddressParse -ipString $dayZeroMappings.NetworkingInformation.SatcomAvailableIP -errVar $parseErrors -varName "EdgeInformation.SatcomNicIP")
	$parseErrors = (Test-CIDRNotation -cidrString $dayZeroMappings.NetworkingInformation.SatcomSubnetCIDR -errVar $parseErrors -varName "EdgeInformation.SatcomSubnet")
}
$parseErrors = (Test-CIDRNotation -cidrString $edgeLanSubnetCidr -errVar $parseErrors -varName "EdgeInformation.LanSubnet")
$parseErrors = (Test-IPAddressParse -ipString $dayZeroMappings.NetworkingInformation.LanGatewayIP -errVar $parseErrors -varName "EdgeInformation.LanGatewayIP")

if ($parseErrors.length -gt 0) {
	throw "Something went wrong validating the format of the provided IP addresses: $newline $newline$parseErrors"
}

$terminalName = $dayZeroMappings.AzureInformation.AOCAResourcePrefix + "-terminal"
$edgeCarName = $dayZeroMappings.AzureInformation.AOCAResourcePrefix + "-car"
$connectionName = $dayZeroMappings.AzureInformation.AOCAResourcePrefix + "-conn"

# If we do not have an ASUS router in this deployment, we would not have any values for SATCOM networking
$satcomSubnet = ($IncludesAsusRouter ? $dayZeroMappings.NetworkingInformation.SatcomSubnetCIDR : "100.64.0.1/10")
$satcomIP = ($IncludesAsusRouter ? $dayZeroMappings.NetworkingInformation.SatcomAvailableIP : "")

$aocaResourceTemplate = Get-Content -Path $AOCANoSdwanResourceJsonTemplateFilePath -Raw
$aocaResourceTemplate = $aocaResourceTemplate `
	-replace "___region___", $dayZeroMappings.AzureInformation.TargetRegion `
	-replace "___edgeCARname___", $edgeCarName `
	-replace "___satcomSubnet___", $satcomSubnet `
	-replace "___satcomNicIP___", $satcomIP `
	-replace "___eLanGWIP___", $dayZeroMappings.NetworkingInformation.LanGatewayIP `
	-replace "___eLanSubnet___", $edgeLanSubnetCidr `
	-replace "___terminalName___", $terminalName `
	-replace "___aseResourceID___", $dayZeroMappings.AzureStackEdgeInformation.AzureStackEdgeResourceID `
	-replace "___vpnGatewayConnectionResourceId___", $vpnGatewayConnectionResourceId `
	-replace "___connectionName___", $connectionName `

# RG deployment allows for Hastable as a input parameter for the template
$hashTableTemplate = $aocaResourceTemplate | ConvertFrom-Json -AsHashtable

# Create the RG if it doesn't exist. If exists, it will no-op
New-AzResourceGroup `
	-Name $dayZeroMappings.AzureInformation.TargetResourceGroupName `
	-Location $dayZeroMappings.AzureInformation.TargetRegion `
	-Force `
	-Verbose

New-AzResourceGroupDeployment `
	-ResourceGroupName $dayZeroMappings.AzureInformation.TargetResourceGroupName `
	-TemplateObject $hashTableTemplate `
	-Verbose `
	-ErrorAction Stop