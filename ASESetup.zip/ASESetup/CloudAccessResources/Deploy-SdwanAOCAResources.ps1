#-------------------------------------------------------------------------------------
# <copyright file="Deploy-SdwanAOCAResources.ps1" company="Microsoft">
#     Copyright (c) Microsoft Corporation. All rights reserved.
# </copyright>
#-------------------------------------------------------------------------------------

<#
	.SYNOPSIS
	Creates all the required Azure Orbital Cloud Access resources needed to set up edge to 
	cloud connectivity.

	.DESCRIPTION
	Leverages various input files (described in the parameters section) to create an Azure
	resource deployment job that generates all the necessary AOCA resources to get edge to
	cloud connectivity up and running.

	! IMPORTANT !
	Please ensure that you've fully filled out the Resource template file, and that your
	PowerShell version is 7.0 - 7.2.10.

	.PARAMETER DayZeroInputFilePath
	Path to the Day Zero Input File template. Must be of file type `.template`.

	.PARAMETER AOCAResourceInputTemplateFilePath
	Path to the filled out template file for AOCA resource creation. Must be of file type
	`.template`.

	.PARAMETER AOCAResourceJsonTemplateFilePath
	Path to the Azure resource template for the AOCA resources. Must be of file type `.json`.

	.PARAMETER DayZeroHelpersFilePath
	Path to the DayZeroHelpers.psm1 file. Stores all of the helper functions for the Day Zero process to run efficiently.

	.EXAMPLE
	PS> .\Deploy-AOCAResources.ps1 -DayZeroInputFile ../InputTemplates/Inputs-JuniperSDWAN.template -AOCAResourceInputTemplateFilePath ../InputTemplates/CloudAccessResourceCreation.template -AOCAResourceJsonTemplateFilePath ./ARMTemplates/AOCA-SdwanResources.json -DayZeroHelpersFilePath ../DayZeroHelpers.psm1
#>
[CmdletBinding()]
param(
	[Parameter(Mandatory=$true)]
	[string]
	$AOCAResourceJsonTemplateFilePath,
	[parameter(mandatory)]
	[PSObject]
	$dayZeroMappings,
	[parameter(mandatory)]
	[PSObject]
	$dayZeroProgress,
	[parameter(mandatory)]
	[SecureString] 
	$conductorSecret,
	[parameter(mandatory)]
	[string]
	$orchestratorProgFilePath
)

$global:jobTerminatingStates = @("Completed", "Failed", "Stopped", "Suspended", "Disconnected")

$tokenSuppress = Get-AzBearerToken -cloudType $dayZeroMappings.AzureEnvironmentOptions.CloudEnvironment `
	-subscriptionID $dayZeroMappings.AzureInformation.TargetSubscriptionID `
	-tenantID $dayZeroMappings.AzureInformation.TargetTenantID

$newline = [System.Environment]::NewLine

$conductorName = $dayZeroProgress.conductorName;

Write-Host -ForegroundColor Yellow "Setting things up before creating Azure Orbital Cloud Access resources..."

$kvName = $conductorName + "-kv";

if (-not $dayZeroProgress.kvSecretIdentifier) {

	Write-Host -ForegroundColor Yellow "Creating key vault for Conductors password."
	
	$secretName = "Conductor-PW"
	
	$conductorKv = New-AzKeyVault -VaultName $kvName `
						-SubscriptionId $dayZeroMappings.AzureInformation.TargetSubscriptionID `
						-ResourceGroupName $dayZeroMappings.AzureInformation.TargetResourceGroupName `
						-Location $dayZeroMappings.AzureInformation.TargetRegion
	
	$secretObject = Set-AzKeyVaultSecret -VaultName $kvName -Name $secretName -SecretValue $conductorSecret
	
	$dayZeroProgress.kvSecretIdentifier = $secretObject.Id
	$dayZeroProgress.kvResourceId = $conductorKv.ResourceId

	$dayZeroProgress | ConvertTo-Json | Set-Content $orchestratorProgFilePath
}
	
$ProviderObjectId = (Get-AzADServicePrincipal -DisplayName "Azure Orbital Resource Provider").id

$controllerUsername = "admin";

$aseResourceId = $dayZeroMappings.AzureStackEdgeInformation.AzureStackEdgeResourceID

# RG of the ASE
$aseRgId = "/" + ($aseResourceId.split("/")[1..4] -Join "/")

Write-Host -ForegroundColor Yellow "Assigning appropriate roles to previously generated resources."

# Role assignment to Azure Orbital Resource Provider
try {
	Update-RoleAssignment -ProviderObjectId $ProviderObjectId `
		-RoleDefinitionName "Key Vault Secrets User" `
		-Scope $dayZeroProgress.kvResourceId
  	
	$suppressOutput = Set-AzKeyVaultAccessPolicy -SubscriptionId $dayZeroMappings.AzureInformation.TargetSubscriptionID -VaultName $kvName -ObjectId $ProviderObjectId -PermissionsToSecrets List,Get

	Update-RoleAssignment -ProviderObjectId $ProviderObjectId `
		-RoleDefinitionName "Contributor" `
		-Scope $aseRgId `
		-IgnoreErrors
}
catch {
	throw $_
}

$cidr = (Convert-Subnetmask -Mask $dayZeroMappings.NetworkingInformation.DedicatedASELanSubnetMask).CIDR
$subnet = ([IPAddress] (([IPAddress] $dayZeroMappings.NetworkingInformation.DedicatedASELanIP).Address -band ([IPAddress] $dayZeroMappings.NetworkingInformation.DedicatedASELanSubnetMask).Address)).ToString()

$edgeSSRSubnetPrefix = $subnet + "/" + $cidr

# Validate IP formatting
$parseErrors = ""

$parseErrors = (Test-IPAddressParse -ipString $dayZeroProgress.satcomGatewayIp -errVar $parseErrors -varName "dayZeroProgress.satcomGatewayIp")
$parseErrors = (Test-IPAddressParse -ipString $dayZeroProgress.satcomNicIp -errVar $parseErrors -varName "dayZeroProgress.satcomNicIp")
$parseErrors = (Test-IPAddressParse -ipString $dayZeroProgress.wanGatewayIp -errVar $parseErrors -varName "dayZeroProgress.wanGatewayIp")
$parseErrors = (Test-IPAddressParse -ipString $dayZeroProgress.wanNicIp -errVar $parseErrors -varName "dayZeroProgress.wanNicIp")
$parseErrors = (Test-IPAddressParse -ipString $dayZeroMappings.EdgeInformation.LanAOCAAgentIP -errVar $parseErrors -varName "EdgeInformation.LanAOCAAgentIP")
$parseErrors = (Test-IPAddressParse -ipString $dayZeroProgress.cloudSSRPublicNicPublicIp -errVar $parseErrors -varName "dayZeroProgress.cloudSSRPublicNicPublicIp")
$parseErrors = (Test-IPAddressParse -ipString $dayZeroProgress.publicGatewayIp -errVar $parseErrors -varName "dayZeroProgress.publicGatewayIp")
$parseErrors = (Test-IPAddressParse -ipString $dayZeroProgress.cloudSSRPublicNicPrivateIp -errVar $parseErrors -varName "dayZeroProgress.cloudSSRPublicNicPrivateIp")
$parseErrors = (Test-IPAddressParse -ipString $dayZeroProgress.privatecGatewayIp -errVar $parseErrors -varName "dayZeroProgress.privatecGatewayIp")
$parseErrors = (Test-IPAddressParse -ipString $dayZeroProgress.cloudSSRPrivateNicPrivateIp -errVar $parseErrors -varName "dayZeroProgress.cloudSSRPrivateNicPrivateIp")
$parseErrors = (Test-IPAddressParse -ipString $dayZeroMappings.NetworkingInformation.DedicatedASELanIP -errVar $parseErrors -varName "dayZeroMappings.NetworkingInformation.DedicatedASELanIP")
$parseErrors = (Test-CIDRNotation -cidrString $dayZeroProgress.satcomSubnet -errVar $parseErrors -varName "dayZeroProgress.satcomSubnet")
$parseErrors = (Test-CIDRNotation -cidrString $dayZeroProgress.wanSubnet -errVar $parseErrors -varName "dayZeroProgress.wanSubnet")
$parseErrors = (Test-CIDRNotation -cidrString $dayZeroProgress.publicSubnet -errVar $parseErrors -varName "dayZeroProgress.publicSubnet")
$parseErrors = (Test-CIDRNotation -cidrString $dayZeroProgress.privateSubnet -errVar $parseErrors -varName "dayZeroProgress.privateSubnet")
$parseErrors = (Test-CIDRNotation -cidrString $edgeSSRSubnetPrefix -errVar $parseErrors -varName "DayZeroInputTemplate.NetworkingInformation.DedicatedASELanIP/SubnetMask")

if ($parseErrors.length -gt 0) {
	throw "Something went wrong validating the format of the provided IP addresses: $newline $newline$parseErrors"
}

$inetBreakoutFlag = ($dayZeroMappings.AzureInformation.InternetBreakoutFlag).ToLower()

$aocaResourceTemplate = Get-Content -Path $AOCAResourceJsonTemplateFilePath -Raw
$aocaResourceTemplate = $aocaResourceTemplate `
	-replace "___region___", $dayZeroMappings.AzureInformation.TargetRegion `
	-replace "___edgeCARname___", $dayZeroMappings.EdgeInformation.EdgeAccessRouterName `
	-replace "___satcomGWIP___", $dayZeroProgress.satcomGatewayIp `
	-replace "___satcomSubnet___", $dayZeroProgress.satcomSubnet `
	-replace "___satcomNicIP___", $dayZeroProgress.satcomNicIp `
	-replace "___satcomVMBUSID___", $dayZeroProgress.satcomVmBusId `
	-replace "___satcomPriority___", $dayZeroMappings.EdgeInformation.SatcomPriority `
	-replace "___secGWIP___", $dayZeroProgress.wanGatewayIp `
	-replace "___secSubnet___", $dayZeroProgress.wanSubnet `
	-replace "___secNicIP___", $dayZeroProgress.wanNicIp `
	-replace "___secVMBUSID___", $dayZeroProgress.wanVmBusId `
	-replace "___secPriority___", $dayZeroMappings.EdgeInformation.SecondaryPriority `
	-replace "___eLanGWIP___", $dayZeroMappings.NetworkingInformation.DedicatedSSRLanGatewayIP `
	-replace "___eLanSubnet___", $edgeSSRSubnetPrefix `
	-replace "___eLanNicIP___", $dayZeroMappings.NetworkingInformation.DedicatedSSRLanGatewayIP `
	-replace "___agentIP___", $dayZeroMappings.EdgeInformation.LanAOCAAgentIP `
	-replace "___eLanVMBUSID___", $dayZeroProgress.lanVmBusId `
	-replace "___terminalName___", $dayZeroMappings.AzureInformation.CloudAccessTerminalName `
	-replace "___aseResourceID___", $dayZeroMappings.AzureStackEdgeInformation.AzureStackEdgeResourceID `
	-replace "___controllerName___", $dayZeroMappings.ControllerInformation.CloudAccessSdwanControllerName `
	-replace "___controllerPIP___", $dayZeroProgress.conductorPublicIpResourceId `
	-replace "___controllerAdminUsername___", $controllerUsername `
	-replace "___controllerPWKV___", $dayZeroProgress.kvSecretIdentifier `
	-replace "___cloudCARName___", $dayZeroMappings.CloudInformation.CloudAccessRouterName `
	-replace "___azPublicIP___", $dayZeroProgress.cloudSSRPublicNicPublicIp `
	-replace "___azPubGWIP___", $dayZeroProgress.publicGatewayIp `
	-replace "___azPubSubnet___", $dayZeroProgress.publicSubnet `
	-replace "___azPubNicIP___", $dayZeroProgress.cloudSSRPublicNicPrivateIp `
	-replace "___azPubVMBUSID___", $dayZeroProgress.publicVmBusId `
	-replace "___azPrivGWIP___", $dayZeroProgress.privatecGatewayIp `
	-replace "___azPrivSubnet___", $dayZeroProgress.privateSubnet `
	-replace "___azPrivNicIP___", $dayZeroProgress.cloudSSRPrivateNicPrivateIp `
	-replace "___azPrivVMBUSID___", $dayZeroProgress.privateVmBusId `
	-replace "___connectionName___", $dayZeroMappings.AzureInformation.CloudAccessConnectionName `
	-replace "___inetBreakoutFlag___", $inetBreakoutFlag

# RG deployment allows for Hastable as a input parameter for the template
$hashTableTemplate = $aocaResourceTemplate | ConvertFrom-Json -AsHashtable

# Create the RG if it doesn't exist. If exists, it will no-op
$suppressOutput = New-AzResourceGroup `
	-Name $dayZeroMappings.AzureInformation.TargetResourceGroupName `
	-Location $dayZeroMappings.AzureInformation.TargetRegion `
	-Force `
	-Verbose

# Kick off resource creation job
$resourceDeploymentJob = New-AzResourceGroupDeployment `
	-ResourceGroupName $dayZeroMappings.AzureInformation.TargetResourceGroupName `
	-TemplateObject $hashTableTemplate `
	-AsJob `
	-ErrorAction Stop

Write-Host -ForegroundColor Yellow "Kicked off Azure Orbital Cloud Access resource creation. Attempting to associate asset IDs."

$plaintextPw = Get-PlainTextPW -Password $conductorSecret

# We should have all the proper info to successfully log into the conductor at this point.
try {
	$conductorBearerToken = Get-ConductorToken `
		-PublicIpAddress $dayZeroProgress.conductorPublicIp `
		-Username "admin" `
		-Key $plaintextPw
}
catch {
	# On the off chance something goes wrong on login, advise customer to manually associate ASSET IDs.
	Write-Error "Unable to log into the Conductor to automatically associate asset IDs. Please refer to Azure Orbital Cloud Access documentation and manually associate."
}

$assetUpdated = $false

# We need to try and associate the ASSET IDs ASAP so that Agent VM provisioning succeeds.
# We'll loop every 15s until we either successfully associate OR the AOCA resource job terminates.
while ($conductorBearerToken -and -not $assetUpdated -and $resourceDeploymentJob.State -notin $jobTerminatingStates) {

	# Attempt asset ID association
	$assetUpdated = Update-RouterAssetID `
		-ConductorBearerToken $conductorBearerToken `
		-ConductorPublicIP $dayZeroProgress.conductorPublicIp `
		-EdgeSSRName $dayZeroMappings.EdgeInformation.EdgeAccessRouterName `
		-EdgeSSRAssetID $dayZeroProgress.edgeSsrAssetId `
		-CloudSSRName $dayZeroMappings.CloudInformation.CloudAccessRouterName `
		-CloudSSRAssetID $dayZeroProgress.cloudSsrAssetId

	if (-not $assetUpdated) {
		Write-Host -ForegroundColor Yellow "Resource creation job status: $($resourceDeploymentJob.State). Asset IDs associated: $assetUpdated. Checking again in 15 seconds..."

		Start-Sleep -Seconds 15	
	}
}

# If asset ID was successfully updated and this is a no-inet breakout deployment, then we need to associated ASE host OS IP to config as well
if ($assetUpdated -and -not [System.Convert]::ToBoolean($inetBreakoutFlag)) {

	$addedHostIP = Update-ASEHostIPTenant `
		-ConductorBearerToken $conductorBearerToken `
		-ConductorPublicIP $dayZeroProgress.conductorPublicIp `
		-EdgeSSRName $dayZeroMappings.EdgeInformation.EdgeAccessRouterName `
		-ASEHostOSIP $dayZeroMappings.NetworkingInformation.DedicatedASELanIP

	if (-not $addedHostIP) {
		Write-Host -ForegroundColor Red "Unable to add Azure Stack Edge host OS IP to Juniper configuration. Please refer to Azure Orbital Cloud Access documentation for manual steps."
	}
}

# This will be skipped if the job finished in a prior step
while ($resourceDeploymentJob.State -notin $jobTerminatingStates) {	
	Write-Host -ForegroundColor Yellow "Resource creation job status: $($resourceDeploymentJob.State). Checking again in 15 seconds..."
	Start-Sleep -Seconds 15
}

# Receive-Job actually outputs any exception immediately, and it is not store-able.
$jobOutput = Receive-Job -Job $resourceDeploymentJob

if ($jobOutput.ProvisioningState -eq "Failed") {
	throw "Failed to create Azure Orbital Cloud Access resources. Refer to previous output for details."
}
else {

	# Need to account for the unlikely case that resources got deployed but the asset ID's aren't associated
	if ($conductorBearerToken -and -not $assetUpdated) {

		# One last attempt...
		$assetUpdated = Update-RouterAssetID `
			-ConductorBearerToken $conductorBearerToken `
			-ConductorPublicIP $dayZeroProgress.conductorPublicIp `
			-EdgeSSRName $dayZeroMappings.EdgeInformation.EdgeAccessRouterName `
			-EdgeSSRAssetID $dayZeroProgress.edgeSsrAssetId `
			-CloudSSRName $dayZeroMappings.CloudInformation.CloudAccessRouterName `
			-CloudSSRAssetID $dayZeroProgress.cloudSsrAssetId
	}

	if (-not $assetUpdated) {
		Write-Host -ForegroundColor Red "Unable to automatically associate asset IDs. Please refer to Azure Orbital Cloud Access documentation and manually associate."
	}
}

return $dayZeroProgress