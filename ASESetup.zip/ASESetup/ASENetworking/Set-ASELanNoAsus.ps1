﻿#-------------------------------------------------------------------------------------
# <copyright file="Set-ASELanNoAsus.ps1" company="Microsoft">
#     Copyright (c) Microsoft Corporation. All rights reserved.
# </copyright>
#-------------------------------------------------------------------------------------

<#

    .SYNOPSIS
    Updates the network configuration of a local Azure Stack Edge.

    .DESCRIPTION
    This script is used to update the LAN config of a local ASE so that
    it meets the requirements of Azure Orbital Cloud Access.

    .EXAMPLE
    PS> $asePassword = Read-Host -AsSecureString
    PS> .\Set-ASELAN.ps1 -ASESerial "ABC123XYZ" -ASEPassword $asePassword -LANIP "10.1.1.0" -SubnetMask "255.255.255.0" -LANGateway "10.1.1.1" -ZtpRestHelpersPath ".\\ZtpRestHelpers.ps1"

    .EXAMPLE
    PS> $asePassword = Read-Host -AsSecureString
    PS> .\Set-ASELAN.ps1 -ASESerial "XYZ123ABC" -ASEPassword $asePassword -LANIP "20.2.2.0" -SubnetMask "255.255.255.0" -LANGateway "20.2.2.1" -ZtpRestHelpersPath ".\\ZtpRestHelpers.ps1" -IsSDWAN

    .EXAMPLE
    PS> $asePassword = Read-Host -AsSecureString
    PS> .\Set-ASELAN.ps1 "123ABCXYZ" $asePassword "192.168.41.0" "255.255.255.0" "192.168.41.30" ".\\ZtpRestHelpers.ps1" -IsSDWAN -SecondarySubnetMask "255.255.255.0" -SecondaryGateway "192.168.50.1"

    .EXAMPLE
    PS> $asePassword = Read-Host -AsSecureString
    PS> .\Set-ASELAN.ps1 -ASESerial "XYZ123ABC" -ASEPassword $asePassword -LANIP "20.2.2.0" -SubnetMask "255.255.255.0" -LANGateway "20.2.2.1" -ZtpRestHelpersPath ".\\ZtpRestHelpers.ps1" -ClearBootstrapperConfig -BootstrapperPort 3


#>
[CmdletBinding()]
Param (
    
    [Parameter(Mandatory=$true)]
    [string]
    # Mandatory parameter. Specifies the serial number of your ASE.
    $ASESerial,
    
    [Parameter(Mandatory=$true)]
    [SecureString]
    # Mandatory parameter. Specifies the GUI password of your ASE.
    $ASEPassword,
    
    [ValidateScript({
        if(-Not ($_ -match[IPAddress]$_)) {
            throw "Please enter an IP address of a valid format."
        }
        return $true
    })]
    [IPAddress]
    # Specifies the IP subnet address of your LAN.
    $LANIP = "10.1.1.2",

    [ValidateScript({
        if(-Not ($_ -match[IPAddress]$_)) {
            throw "Please enter an IP address of a valid format."
        }
        return $true
    })]
    [string]
    # Subnet mask for the LAN IP. Defaults to 255.255.255.0, or /24
    $SubnetMask = "255.255.255.0",

    [ValidateScript({
        if(-Not ($_ -match[IPAddress]$_)) {
            throw "Please enter an IP address of a valid format."
        }
        if($_ -eq $LANIP){
            throw "Please enter a gateway different than the LAN IP."
        }
        return $true
    })]
    [IPAddress]
    # Specifies the gateway address of your LAN IP.
    $LANGateway = "10.1.1.1",

    [ValidateScript({
		if($_ -notmatch "(\.ps1)$"){
			throw "The file specified in the path argument must be of type ps1"
		}
		return $true 
	})]
    [Parameter(Mandatory=$true)]
    [string]
    # Path to ZTP rest helpers, required for configuring local ASE
    $ZtpRestHelpersPath,
    
    [switch]
    # Whether or not you are using an SD-WAN solution. Set to FALSE if left empty.
    $IsSDWAN,

    [ValidateScript({
        if(-Not ($_ -match[IPAddress]$_)) {
            throw "Please enter an IP address of a valid format."
        }
        return $true
    })]
    [string]
    # Subnet mask for the SECONDARY IP.
    $SecondarySubnetMask,

    [ValidateScript({
        if(-Not ($_ -match[IPAddress]$_)) {
            throw "Please enter an IP address of a valid format."
        }
        return $true
    })]
    [string]
    # Specifies the gateway address of your SECONDARY network.
    $SecondaryGateway,

    [ValidateScript({
        if(-Not ($_ -match[IPAddress]$_)) {
            throw "Please enter an IP address of a valid format."
        }
        return $true
    })]
    [string]
    # Specifies the SECONDARY network address.
    $SecondaryNetwork,

    [switch]
    # Whether or not bootstrapper configuration is being cleared.
    $ClearBootstrapperConfig,

    [int]
    # Port number used for bootstrapping
    $BootstrapperPort

)

<#
    .SYNOPSIS
    This function clears the bootstrapper host NIC configuration from the ASE, forcing it to go through the LAN NIC
#>
function Clear-BootstrapperNICConfiguration() {
    param(
        [parameter(mandatory)]
        [PSObject]
        $aseConfig,

        [parameter(mandatory)]
        [int]
        $BootstrapperPort,
        
        [parameter(mandatory)]
        [IPAddress]
        $LANIP
    )

    # 20 bouts of 15 seconds = 5 minutes
    $timeout = 20

    # Host NIC may take some time to come up when first plugged into, will need to loop connectivity test
    # to only proceed once it's ready. Test-NetConnection is handy here.
    $hostAccessible = Test-NetConnection -ComputerName $LANIP `
        -InformationLevel Quiet `
        -WarningAction SilentlyContinue

    while (-not $hostAccessible) {

        Write-Host -ForegroundColor Yellow "Waiting for ASE host connectivity, trying again in 15 seconds..."

        if ($timeout -eq 0) {
            throw "Unable to establish connectivity to the ASE Host. Please ensure you are connected to the LAN port and try again in 10 minutes. If the problem persists, please contact AOCA support."
        }

        $timeout = $timeout - 1
        Start-Sleep -Seconds 15

        $hostAccessible = Test-NetConnection -ComputerName $LANIP `
            -InformationLevel Quiet `
            -WarningAction SilentlyContinue

    }

    Write-Host -ForegroundColor Yellow "Connectivity established, updating bootstrapper port..."
    $networkObj = $aseConfig.device.network
    $networkObj.interfaces[$BootstrapperPort-1].iPv4 = @{}
    $networkObj.interfaces[$BootstrapperPort-1].iPv6 = @{}
    $networkObj.interfaces[$BootstrapperPort-1].dnsServerAddresses = @()
    $networkObj.interfaces[$BootstrapperPort-1].isDhcpEnabled = "False"
    $networkObj.interfaces[$BootstrapperPort-1].ipConfigType = "IPLess"

    return $networkObj

}

<#
    .SYNOPSIS
    Sets up vSwitch + vNET configuration on the ASE for the desired AOCA version
#>
function Write-ASENetworkingConfig() {
    param(
        [parameter(mandatory)]
        [Boolean]
        $IsSDWAN,

        [parameter(mandatory)]
        [PSObject]
        $aseConfig,

        [parameter(mandatory)]
        [IPAddress]
        $LANIP,

        [parameter(mandatory)]
        [string]
        $SubnetMask,

        [parameter(mandatory)]
        [IPAddress]
        $LANGateway,

        [string]
        $SecondarySubnetMask,

        [string]
        $SecondaryGateway,

        [string]
        $SecondaryNetwork
    )

    # If SD-WAN, port 3 must be used for LAN configuration, otherwise port 2
    $LANPort = if ($IsSDWAN) { 3 } Else { 2 }

    # Set transport ports, SATCOM is always 1, SECONDARY is either port 2 or N/A
    $SATCOMPort = 1
    $SECONDARYPort = if ($IsSDWAN) { 2 }

    # Update network configuration object interfaces
    $networkObj = $aseConfig.device.network
    $networkObj.interfaces[$LANPort-1].isDhcpEnabled = "False"
    $networkObj.interfaces[$LANPort-1].dnsServerAddresses = "8.8.8.8", "8.8.4.4"
    $networkObj.interfaces[$LANPort-1].iPv4 = @{'address'=$LANIP.IPAddressToString; 'subnetMask'=$SubnetMask; 'gateway'=$LANGateway.IPAddressToString}

    # Deny the ASE from taking a host NIC on Starlink
    $networkObj.interfaces[0].iPv4 = @{}
    $networkObj.interfaces[0].iPv6 = @{}
    $networkObj.interfaces[0].dnsServerAddresses = @()
    $networkObj.interfaces[0].isDhcpEnabled = "False"
    $networkObj.interfaces[0].ipConfigType = "IPLess"

    # Update vSwitches

    # Add SATCOM switch & vNet
    $satcomJson = '{ "name":"SATCOMSwitch", "interfaces": [ "Port' + ($SATCOMPort) + '" ], "enabledForCompute":"false", "enabledForStorage":"false", "enabledForMgmt":"false", "supportsAcceleratedNetworking":"false", "enableEmbeddedTeaming":"false", "ipAddressPools":"" }'
    $satcomObj = ConvertFrom-Json -InputObject $satcomJson
    $networkObj.vSwitches += $satcomObj

    $satcomCidr = (Convert-Subnetmask -Mask "255.192.0.0").CIDR
    $satcomvNetJson = '{ "name": "SATCOM", "vSwitchName": "SATCOMSwitch", "vlanId": 0, "gateway": "100.64.0.1", "network": "100.64.0.0/' + $satcomCidr + '" }'
    $satcomvNetObj = ConvertFrom-Json -InputObject $satcomvNetJson
    $networkObj.virtualNetworks += $satcomvNetObj

    # Add SECONDARY switch if applicable
    if ($SECONDARYPort) {
        # Deny the ASE from taking a host NIC on Secondary
        $networkObj.interfaces[$SECONDARYPort-1].iPv4 = @{}
        $networkObj.interfaces[$SECONDARYPort-1].iPv6 = @{}
        $networkObj.interfaces[$SECONDARYPort-1].dnsServerAddresses = @()
        $networkObj.interfaces[$SECONDARYPort-1].isDhcpEnabled = "False"
        $networkObj.interfaces[$SECONDARYPort-1].ipConfigType = "IPLess"

        $secondaryJson = '{ "name":"SECONDARYSwitch", "interfaces": [ "Port' + ($SECONDARYPort) + '" ], "enabledForCompute":"false", "enabledForStorage":"false", "enabledForMgmt":"false", "supportsAcceleratedNetworking":"false", "enableEmbeddedTeaming":"false", "ipAddressPools":"" }'
        $secondaryObj = ConvertFrom-Json -InputObject $secondaryJson
        $networkObj.vSwitches += $secondaryObj

        $secondaryCidr = (Convert-Subnetmask -Mask $SecondarySubnetMask).CIDR
        $secondaryvNetJson = '{ "name": "SECONDARY", "vSwitchName": "SECONDARYSwitch", "vlanId": 0, "gateway": "' + ($SecondaryGateway) + '", "network": "' + ($SecondaryNetwork) + '/' + $secondaryCidr + '" }'
        $secondaryvNetObj = ConvertFrom-Json -InputObject $secondaryvNetJson
        $networkObj.virtualNetworks += $secondaryvNetObj
    }

    # Add LAN switch    
    $LANJson = '{ "name":"LAN", "interfaces": [ "Port' + ($LANPort) + '" ], "enabledForCompute":"false", "enabledForStorage":"false", "enabledForMgmt":"false", "supportsAcceleratedNetworking":"false", "enableEmbeddedTeaming":"false", "ipAddressPools":"" }'
    $LANObj = ConvertFrom-Json -InputObject $LANJson
    $networkObj.vSwitches += $LANObj

    return $networkObj

}

<#
    .SYNOPSIS
    Sends the networking config package to the ASE for update and monitors its progress.
#>
function Set-ASEConfig() {

    param(
        [parameter(mandatory)]
        [PSObject]
        $aseConfig,

        [switch]
        $ignoreErrors
    )

    # Grab current config status, in case changes are being made in real time
    $curStatus = Get-DeviceConfigurationStatus

    # Status can be complete if a config update was done recently...
    if (($curStatus.deviceConfiguration.status -ne "None") -and ($curStatus.deviceConfiguration.status -ne "Complete")) {
        throw "This ASE is currently busy and has a configuration status of " + $curStatus.deviceConfiguration.status + ". Please try running this script again in a few minutes. If this continues to occur, restart your ASE."
    }

    # Prepare package to send to ASE
    $pkg = New-Package -network $networkObj

    $newConfig = Set-DeviceConfiguration -desiredDeviceConfig $pkg

    # Loop through the current status until the update completes, checking every 10 seconds
    $curStatus = Get-DeviceConfigurationStatus

    $retryCount = 5

    # Retry as there are times where we update the network we are connected to and so connectivity may be temporarily severed
    while ($curStatus.deviceConfiguration.status -eq "InProgress" -and $retryCount -ne 0) {
        try {
            Write-Host -ForegroundColor Yellow "Configuration update status: $($curStatus.deviceConfiguration.status). Please wait..."
            Start-Sleep -Seconds 10
            $curStatus = Get-DeviceConfigurationStatus
        }
        catch {
            $lastErr = $_
            $retryCount = $retryCount - 1   
            Start-Sleep -Seconds 10
        }
    }

    if ($retryCount -eq 0) {
        throw $lastErr
    }

    # Grab results...
    $resultString = $curStatus.deviceConfiguration.results | ConvertTo-Json

    # If that result code is not Success, something went wrong during update. Result object will relay the issue to the user...
    # There is a case where we want to actually ignore errors. This is due to gateway unreachability while clearing bootstrapping port config.
    if ($curStatus.deviceConfiguration.results.resultCode -ne "Success" -and -not $ignoreErrors) {
        throw "Something went wrong during configuration update: `n$($resultString)"
    }

    Write-Host -ForegroundColor Green ($ignoreErrors ? "Successfully applied update to ASE!" : "Successfully applied update to ASE: `n$($resultString)")
}

# BEGIN main process

# Import ZTP module
Import-Module $ZtpRestHelpersPath -Force

$ASEPW = Get-PlainTextPW -Password $ASEPassword

Try {

    # Set ASE login
    Set-Login "https://$($ASESerial).local" "$($ASEPW)" -ErrorAction Stop

}
Catch {

    # Prevent user password from surfacing on errors.
    throw ("$_".replace($ASEPW, "[redacted]"))
    
}

# Retrieve current configuration to work off of
$aseConfig = Get-DeviceConfiguration
    
# Check if get config call worked
if (-not $aseConfig) {

    throw "No configuration found, please ensure you are on the same network as your ASE. $_"

}

if ($ClearBootstrapperConfig) {

    $networkObj = Clear-BootstrapperNICConfiguration -aseConfig $aseConfig `
        -BootstrapperPort $BootstrapperPort `
        -LANIP $LANIP

    Set-ASEConfig -aseConfig $aseConfig -ignoreErrors

}
else {

    if ($IsSDWAN) {
        $networkObj = Write-ASENetworkingConfig -IsSDWAN $IsSDWAN `
            -aseConfig $aseConfig `
            -LANIP $LANIP `
            -SubnetMask $SubnetMask `
            -LANGateway $LANGateway `
            -SecondarySubnetMask $SecondarySubnetMask `
            -SecondaryGateway $SecondaryGateway `
            -SecondaryNetwork $SecondaryNetwork
    }
    else {
        $networkObj = Write-ASENetworkingConfig -IsSDWAN $IsSDWAN `
            -aseConfig $aseConfig `
            -LANIP $LANIP `
            -SubnetMask $SubnetMask `
            -LANGateway $LANGateway
    }

    Set-ASEConfig -aseConfig $aseConfig

}