# !/usr/bin/bash
# -------------------------------------------------------------------------------------
# <copyright file="EnableSnatCommand.sh" company="Microsoft">
#     Copyright (c) Microsoft Corporation. All rights reserved.
# </copyright>
# -------------------------------------------------------------------------------------

# This script contains a command that executes the actual EnableSnat script contained in the VM.
bash /usr/sbin/EnableSnat.sh ___aseIp___

exit $?