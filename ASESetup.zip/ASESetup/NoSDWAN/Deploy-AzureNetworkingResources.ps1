#-------------------------------------------------------------------------------------
# <copyright file="Deploy-AzureNetworkingResources.ps1" company="Microsoft">
#     Copyright (c) Microsoft Corporation. All rights reserved.
# </copyright>
#-------------------------------------------------------------------------------------

<#
    .SYNOPSIS
    This script creates all of the necessary Azure networking components needed for our
    no-SDWAN version of AOCA to work properly. Utilizes the customer's login credentials
    and deploys them against the subscription defined in our no-SDWAN input template.
#>
param (
    [parameter(mandatory)]
    [PSObject]
    $dayZeroMappings,
    [parameter(mandatory)]
    [string]
    $edgeLanSubnetCidr,
    [parameter(mandatory)]
    [string]
    $connectionPeerId,
    [parameter(mandatory)]
    [string]
    $connectionPreSharedKey,
    [parameter(mandatory)]
    [string]
    $vpnGwSku
)

$newline = [System.Environment]::NewLine

$resourcePrefix = $dayZeroMappings.AzureInformation.AzureResourcePrefix

if (-not [boolean]($resourcePrefix -match "^[a-z][a-z0-9-]{1,61}[a-z0-9]$")) {
    throw "Resource prefix '$resourcePrefix' can only include letters, numbers, and '-'."
}

$cloudEnvironment = $dayZeroMappings.AzureEnvironmentOptions.CloudEnvironment
$subscriptionId = $dayZeroMappings.AzureInformation.TargetSubscriptionID
$tenantId = $dayZeroMappings.AzureInformation.TargetTenantID

$tokenSuppress = Get-AzBearerToken -cloudType $cloudEnvironment `
    -subscriptionID $subscriptionId `
    -tenantID $tenantId `
    -forceLogin

try {
    # Installs bicep if not already installed on users machine
    $suppressOutput = Install-Bicep
}
catch {
    throw "Error trying to install Bicep to local machine: $_"
}

$resourceGroupName = $dayZeroMappings.AzureInformation.TargetResourceGroupName
$region = $dayZeroMappings.AzureInformation.TargetRegion

$suppressOutput = New-AzResourceGroup -Name $resourceGroupName -Location $region -Force

$allowInternetBreakout = [System.Convert]::ToBoolean($dayZeroMappings.AzureInformation.AllowInternetBreakout)

# Ensure the vnet ranges are valid
$parseErrors = ""

$parseErrors = (Test-CIDRNotation -cidrString $dayZeroMappings.AzureInformation.AzurevNetIPAddressSpace -errVar $parseErrors -varName "dayZeroMappings.AzureInformation.AzurevNetIPAddressSpace")
$parseErrors = (Test-CIDRNotation -cidrString $dayZeroMappings.AzureInformation.AzurevNetDefaultSubnetAddressSpace -errVar $parseErrors -varName "dayZeroMappings.AzureInformation.AzurevNetDefaultSubnetAddressSpace")
$parseErrors = (Test-CIDRNotation -cidrString $dayZeroMappings.AzureInformation.AzurevNetVPNGatewaySubnetAddressSpace -errVar $parseErrors -varName "dayZeroMappings.AzureInformation.AzurevNetVPNGatewaySubnetAddressSpace")
$parseErrors = (Test-CIDRNotation -cidrString $dayZeroMappings.AzureInformation.AzurevNetFirewallSubnetAddressSpace -errVar $parseErrors -varName "dayZeroMappings.AzureInformation.AzurevNetFirewallSubnetAddressSpace")
$parseErrors = (Test-IPAddressParse -ipString $dayZeroMappings.NetworkingInformation.LanGatewayIP -errVar $parseErrors -varName "dayZeroMappings.NetworkingInformation.LanGatewayIP")

if ($parseErrors.length -gt 0) {
	throw "Something went wrong validating the format of the provided IP addresses: $newline $newline$parseErrors"
}

$cloudVnetCidr =  $dayZeroMappings.AzureInformation.AzurevNetIPAddressSpace
$defaultSubnetCidr = $dayZeroMappings.AzureInformation.AzurevNetDefaultSubnetAddressSpace
$vpnGatewaySubnetCidr = $dayZeroMappings.AzureInformation.AzurevNetVPNGatewaySubnetAddressSpace
$firewallSubnetCidr = $dayZeroMappings.AzureInformation.AzurevNetFirewallSubnetAddressSpace
$lanGatewayIp = $dayZeroMappings.NetworkingInformation.LanGatewayIP

# ToLower is called because some resources cannot have uppercase letters in their resource names (public IP) ??
$templateParams = @{ 
    resourcePrefix = $resourcePrefix.ToLower(); `
    region = $region; `
    edgeLanSubnetCidr = $edgeLanSubnetCidr; `
    cloudVnetCidr =  $cloudVnetCidr
    defaultSubnetCidr = $defaultSubnetCidr
    vpnGatewaySubnetCidr = $vpnGatewaySubnetCidr
    firewallSubnetCidr = $firewallSubnetCidr
    connectionPeerId = $connectionPeerId; `
    allowInternetBreakout = $allowInternetBreakout; `
    connectionPreSharedKey = $connectionPreSharedKey; `
    vpnGwSku = $vpnGwSku; `
    lanGatewayIp = $lanGatewayIp; `
}

$bicepTemplatePath = $dayZeroMappings.DayZeroFilePaths.AzureResourceBicepTemplatePath

try {
    $deploymentOutput = New-AzResourceGroupDeployment -ResourceGroupName $resourceGroupName `
        -TemplateFile $bicepTemplatePath `
        -TemplateParameterObject $templateParams `
        -Verbose `
        -ErrorAction Stop
}
catch {
    # Delete any intermediate resources that may have been created if errors occur
    Remove-NSDAzureNetworkingResources -resourceGroupName $resourceGroupName -resourcePrefix $resourcePrefix
    throw
}

return $deploymentOutput