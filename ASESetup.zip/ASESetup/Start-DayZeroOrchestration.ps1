#-------------------------------------------------------------------------------------
# <copyright file="Start-DayZeroOrchestration.ps1" company="Microsoft">
#     Copyright (c) Microsoft Corporation. All rights reserved.
# </copyright>
#-------------------------------------------------------------------------------------

<#
    .SYNOPSIS
    Sets up all of the necessary day zero resources for Azure Orbital Cloud Access.

    .DESCRIPTION
    Creates all of the necessary local and Azure resources for Azure Orbital Cloud Access depending on the 
    input template file that is provided. Please ensure that all of the file paths located in the template file 
    are correct before proceeding.

    ! IMPORTANT !
    Make sure that your PowerShell version is 7.0 or higher.

    .PARAMETER DayZeroInputFilePath
    Path to the Day Zero Input File template. Must be of file type `.template`.

    .PARAMETER DayZeroHelpersFilePath
    Path to the DayZeroHelpers.psm1 file. Stores all of the helper functions for the Day Zero process to run efficiently.

    .EXAMPLE
    PS> .\Start-DayZeroOrchestration.ps1 -DayZeroInputFilePath .\InputTemplates\Inputs-JuniperSDWAN.template -DayZeroHelpersFilePath .\DayZeroHelpers.psm1
#>
[CmdletBinding()]
param(

	[ValidateScript({
		if($_ -notmatch "(\.template)$"){
			throw "The file specified in the path argument must be of type template"
		}
		return $true 
	})]
	[Parameter(Mandatory=$true)]
	$DayZeroInputFilePath,
    [ValidateScript({
		if($_ -notmatch "(\.psm1)$"){
			throw "The file specified in the path argument must be of type psm1"
		}
		return $true 
	})]	
	[Parameter(Mandatory=$true)]
	$DayZeroHelpersFilePath = '.\DayZeroHelpers.psm1'
)

$global:orchestratorProgFilePath = './orchestrator-progress.tmp'

<#
    .SYNOPSIS
    This function runs all the necessary steps to get a Juniper SD-WAN on an ASE up and running for a customer
#>
function Start-JuniperASEDayZero() {
    param(
        [parameter(mandatory)]
        [PSObject]
        $dayZeroMappings,
        [parameter(mandatory)]
        [Boolean]
        $includesAsusRouter
    )
    enum DayZeroStagesJuniperASE {
        vSwitchCreation = 1
        ConductorDeployment = 2
        CloudSSRDeployment = 3
        EdgeSSRImageDeployment = 4
        EdgeSSRVMDeployment = 5
        EdgeSSRCustomScriptExtension = 6
        AOCAResourcesDeployment = 7
        DisableBootstrapperHostNic = 8
    }
    # Check for progress file, create it if it does not exist
    if (Test-Path -Path $orchestratorProgFilePath -PathType Leaf) {
        $existingProgress = Get-Content -Path $orchestratorProgFilePath | ConvertFrom-Json

        if ($existingProgress.dayZeroStep) {
            $dayZeroProgress = @{
                dayZeroStep=$existingProgress.dayZeroStep; `
                virtualNetworkName=$existingProgress.virtualNetworkName; `
                conductorPublicIp=$existingProgress.conductorPublicIp; `
                SSRImageName=$existingProgress.SSRImageName; `
                SSRVMName=$existingProgress.SSRVMName; `
                privateVmBusId=$existingProgress.privateVmBusId; `
                publicVmBusId=$existingProgress.publicVmBusId; `
                cloudSSRPrivateNicPrivateIp=$existingProgress.cloudSSRPrivateNicPrivateIp; `
                cloudSSRPublicNicPrivateIp=$existingProgress.cloudSSRPublicNicPrivateIp; `
                cloudSSRPublicNicPublicIp=$existingProgress.cloudSSRPublicNicPublicIp; `
                publicSubnet=$existingProgress.publicSubnet; `
                privateSubnet=$existingProgress.privateSubnet; `
                publicGatewayIp=$existingProgress.publicGatewayIp; `
                privatecGatewayIp=$existingProgress.privatecGatewayIp; `
                satcomGatewayIp=$existingProgress.satcomGatewayIp; `
                satcomSubnet=$existingProgress.satcomSubnet; `
                satcomVmBusId=$existingProgress.satcomVmBusId; `
                satcomNicIp=$existingProgress.satcomNicIp; `
                wanGatewayIp=$existingProgress.wanGatewayIp; `
                wanSubnet=$existingProgress.wanSubnet; `
                wanVmBusId=$existingProgress.wanVmBusId; `
                wanNicIp=$existingProgress.wanNicIp; `
                lanGatewayIp=$existingProgress.lanGatewayIp; `
                lanSubnet=$existingProgress.lanSubnet; `
                lanVmBusId=$existingProgress.lanVmBusId; `
                lanNicIp=$existingProgress.lanNicIp; `
                conductorPublicIpResourceId=$existingProgress.conductorPublicIpResourceId; `
                conductorName=$existingProgress.conductorName; `
                kvSecretIdentifier=$existingProgress.kvSecretIdentifier; `
                kvResourceId=$existingProgress.kvResourceId; `
                edgeSsrAssetId=$existingProgress.edgeSsrAssetId; `
                cloudSsrAssetId=$existingProgress.cloudSsrAssetId; `
                timer=$existingProgress.timer; `
                interruptions=$existingProgress.interruptions; `
            }
        }
    } 

    if (-not $dayZeroProgress) {
        $dayZeroProgress = @{
            dayZeroStep=1; `
            virtualNetworkName=""; `
            conductorPublicIp=""; `
            SSRImageName=""; `
            SSRVMName=""; `
            privateVmBusId=""; `
            publicVmBusId=""; `
            cloudSSRPrivateNicPrivateIp=""; `
            cloudSSRPublicNicPrivateIp=""; `
            cloudSSRPublicNicPublicIp=""; `
            publicSubnet=""; `
            privateSubnet=""; `
            publicGatewayIp=""; `
            privatecGatewayIp=""; `
            satcomGatewayIp=""; `
            satcomSubnet=""; `
            satcomVmBusId=""; `
            satcomNicIp=""; `
            wanGatewayIp=""; `
            wanSubnet=""; `
            wanVmBusId=""; `
            wanNicIp=""; `
            lanGatewayIp=""; `
            lanSubnet=""; `
            lanVmBusId=""; `
            lanNicIp=""; `
            conductorPublicIpResourceId=""; `
            conductorName=""; `
            kvSecretIdentifier=""; `
            kvResourceId=""; `
            edgeSsrAssetId=""; `
            cloudSsrAssetId=""; `
            timer = 0,0,0,0,0,0,0,0; `
            interruptions = 0,0,0,0,0,0,0,0; `
        }

        $dayZeroProgress | ConvertTo-Json | Set-Content $orchestratorProgFilePath
    }

    $timer.stop()
    $dayZeroProgress.timer[0] += $timer.elapsed.totalseconds

    # Prompt user for various passwords, based off what step in the day-zero process they are in
    switch ($dayZeroProgress.dayZeroStep) {
        { [DayZeroStagesJuniperASE]$_ -eq 1 -or -not $includesAsusRouter } {
            do {
                $aseLocalPassword = Read-Host -AsSecureString "Please enter your password for the Azure Stack Edge's local UI"
            }
            while ($aseLocalPassword.Length -eq 0)
        }
        { [DayZeroStagesJuniperASE]$_ -le 7 } {
            do {
                $juniperDefaultPassword = Read-Host -AsSecureString "Please enter the default password for the Juniper Conductor. Refer to Azure Orbital Cloud Access documentation if you do not know it"
            }
            while ($juniperDefaultPassword.Length -eq 0)
        }
        { [DayZeroStagesJuniperASE]$_ -le 3 } {
            $targetRegion = ($dayZeroMappings.AzureInformation.TargetRegion).ToLower()

            # Availability zones are only available in Virginia
            if ($targetRegion -eq "usgovvirginia" -or $targetRegion -eq "usgov virginia" -or $dayZeroMappings.AzureEnvironmentOptions.CloudEnvironment -eq "commercial") {
                
                $decision = Receive-UserConfirmation -Prompt "Would you like to deploy your cloud resources in an Availability Zone?"
                
                if ($decision) {
                    $conductorTemplatePath = $dayZeroMappings.DayZeroFilePaths.ConductorASTemplatePath
                    $cloudSSRTemplatePath = $dayZeroMappings.DayZeroFilePaths.CloudSSRASTemplatePath
                }
            }
            
            if (-not $conductorTemplatePath) {
                $conductorTemplatePath = $dayZeroMappings.DayZeroFilePaths.ConductorTemplatePath
                $cloudSSRTemplatePath = $dayZeroMappings.DayZeroFilePaths.CloudSSRTemplatePath
            }
        }
    }

    $newline = [System.Environment]::NewLine

    # vSwitch Configuration
    if ([DayZeroStagesJuniperASE]$dayZeroProgress.dayZeroStep -eq 1) {

        Write-Host -ForegroundColor Green "$newline$($newline)Begin day zero step: $([DayZeroStagesJuniperASE]$dayZeroProgress.dayZeroStep)$newline$newline"
        
        # Start a timer for day0 metrics
        $timer = [Diagnostics.Stopwatch]::StartNew()

        try {
            if ($includesAsusRouter) {
                (& $dayZeroMappings.DayZeroFilePaths.SetASELanScriptPath `
                    -ASESerial $dayZeroMappings.AzureStackEdgeInformation.AzureStackEdgeNodeSerialNumber `
                    -ASEPassword $aseLocalPassword `
                    -LANIP $dayZeroMappings.NetworkingInformation.DedicatedASELanIP `
                    -SubnetMask $dayZeroMappings.NetworkingInformation.DedicatedASELanSubnetMask `
                    -LANGateway $dayZeroMappings.NetworkingInformation.DedicatedSSRLanGatewayIP `
                    -ZtpRestHelpersPath $dayZeroMappings.DayZeroFilePaths.ZtpRestHelpersPath `
                    -IsSDWAN)
            }
            else {
                # We include secondary network info since we have to build an ASE vNET using that information
                (& $dayZeroMappings.DayZeroFilePaths.SetASELanScriptPath `
                    -ASESerial $dayZeroMappings.AzureStackEdgeInformation.AzureStackEdgeNodeSerialNumber `
                    -ASEPassword $aseLocalPassword `
                    -LANIP $dayZeroMappings.NetworkingInformation.DedicatedASELanIP `
                    -SubnetMask $dayZeroMappings.NetworkingInformation.DedicatedASELanSubnetMask `
                    -LANGateway $dayZeroMappings.NetworkingInformation.DedicatedSSRLanGatewayIP `
                    -ZtpRestHelpersPath $dayZeroMappings.DayZeroFilePaths.ZtpRestHelpersPath `
                    -IsSDWAN `
                    -SecondarySubnetMask $dayZeroMappings.NetworkingInformation.SecondaryNetworkSubnetMask `
                    -SecondaryGateway $dayZeroMappings.NetworkingInformation.SecondaryNetworkGatewayIP `
                    -SecondaryNetwork $dayZeroMappings.NetworkingInformation.SecondaryNetworkIP)
            }
        }
        catch {
            $timer.stop()
            $dayZeroProgress.timer[$dayZeroProgress.dayZeroStep] += $timer.elapsed.totalseconds
            $dayZeroProgress.interruptions[$dayZeroProgress.dayZeroStep] += 1
            $dayZeroProgress | ConvertTo-Json | Set-Content $orchestratorProgFilePath

            Write-Error "Error occurred when configuring ASE virtual switches: $_"
            throw
        }

        Write-Host -ForegroundColor Cyan "From this point forward, please have a device or switch plugged into the LAN port so that it is powered on."

        $timer.stop()
        $dayZeroProgress.timer[$dayZeroProgress.dayZeroStep] += $timer.elapsed.totalseconds

        [DayZeroStagesJuniperASE]$dayZeroProgress.dayZeroStep = 2

        $dayZeroProgress | ConvertTo-Json | Set-Content $orchestratorProgFilePath
    }

    # Deploy Conductor
    if ([DayZeroStagesJuniperASE]$dayZeroProgress.dayZeroStep -eq 2) {

        Write-Host -ForegroundColor Green "$newline$($newline)Begin day zero step: $([DayZeroStagesJuniperASE]$dayZeroProgress.dayZeroStep)$newline$newline"
        
        # Start a timer for day0 metrics
        $timer = [Diagnostics.Stopwatch]::StartNew()

        try {

            $conductorOutput = (& $dayZeroMappings.DayZeroFilePaths.ConductorDeployPath `
                -dayZeroMappings $dayZeroMappings `
                -password $juniperDefaultPassword `
                -conductorTemplatePath $conductorTemplatePath)
        }
        catch {
            $timer.stop()
            $dayZeroProgress.timer[$dayZeroProgress.dayZeroStep] += $timer.elapsed.totalseconds
            $dayZeroProgress.interruptions[$dayZeroProgress.dayZeroStep] += 1
            $dayZeroProgress | ConvertTo-Json | Set-Content $orchestratorProgFilePath

            Write-Error "Error occurred when deploying the Juniper Conductor."
            throw
        }
        
        $dayZeroProgress.virtualNetworkName = $conductorOutput.virtualNetworkName
        $dayZeroProgress.conductorPublicIp = $conductorOutput.publicIpAddress
        $dayZeroProgress.conductorPublicIpResourceId = $conductorOutput.conductorPublicIpResourceId
        $dayZeroProgress.conductorName = $conductorOutput.conductorName

        $timer.stop()
        $dayZeroProgress.timer[$dayZeroProgress.dayZeroStep] += $timer.elapsed.totalseconds

        [DayZeroStagesJuniperASE]$dayZeroProgress.dayZeroStep = 3

        $dayZeroProgress | ConvertTo-Json | Set-Content $orchestratorProgFilePath
    }

    # Deploy CloudSSR
    if ([DayZeroStagesJuniperASE]$dayZeroProgress.dayZeroStep -eq 3) {

        Write-Host -ForegroundColor Green "$newline$($newline)Begin day zero step: $([DayZeroStagesJuniperASE]$dayZeroProgress.dayZeroStep)$newline$newline"

        # We need to ensure that the dependencies of this step are present and valid
        switch ($dayZeroProgress) {
            { -not $_.virtualNetworkName } {
                $dayZeroProgress.virtualNetworkName = Read-Host "Did not find a valid value for the pre-existing Conductor's Virtual Network name. Please provide it now"
            }
            { -not $_.conductorPublicIp } {
                $dayZeroProgress.conductorPublicIp = Read-Host "Did not find a valid value for the Conductor's Public IP. Please provide it now"
            }
        }

        # Start a timer for day0 metrics
        $timer = [Diagnostics.Stopwatch]::StartNew()

        try {
            $cloudSSROutput = (& $dayZeroMappings.DayZeroFilePaths.CloudSSRDeployPath `
                -dayZeroMappings $dayZeroMappings `
                -cloudSSRTemplatePath $cloudSSRTemplatePath `
                -conductorPublicIp $dayZeroProgress.conductorPublicIp `
                -virtualNetworkName $dayZeroProgress.virtualNetworkName)
        }
        catch {
            $timer.stop()
            $dayZeroProgress.timer[$dayZeroProgress.dayZeroStep] += $timer.elapsed.totalseconds
            $dayZeroProgress.interruptions[$dayZeroProgress.dayZeroStep] += 1
            $dayZeroProgress | ConvertTo-Json | Set-Content $orchestratorProgFilePath

            Write-Error "Error occurred when deploying the Juniper Azure SSR."
            throw
        }
        
        $dayZeroProgress.cloudSSRPrivateNicPrivateIp = $cloudSSROutput.cloudSSRPrivateNicPrivateIp
        $dayZeroProgress.cloudSSRPublicNicPrivateIp = $cloudSSROutput.cloudSSRPublicNicPrivateIp
        $dayZeroProgress.cloudSSRPublicNicPublicIp = $cloudSSROutput.cloudSSRPublicNicPublicIp
        $dayZeroProgress.publicSubnet = $cloudSSROutput.publicSubnet
        $dayZeroProgress.privateSubnet = $cloudSSROutput.privateSubnet
        $dayZeroProgress.publicGatewayIp = $cloudSSROutput.publicGatewayIp
        $dayZeroProgress.privatecGatewayIp = $cloudSSROutput.privatecGatewayIp
        $dayZeroProgress.privateVmBusId = $cloudSSROutput.privateVmBusId
        $dayZeroProgress.publicVmBusId = $cloudSSROutput.publicVmBusId
        $dayZeroProgress.cloudSsrAssetId = $cloudSSROutput.cloudSsrAssetId 

        $timer.stop()
        $dayZeroProgress.timer[$dayZeroProgress.dayZeroStep] += $timer.elapsed.totalseconds

        [DayZeroStagesJuniperASE]$dayZeroProgress.dayZeroStep = 4

        $dayZeroProgress | ConvertTo-Json | Set-Content $orchestratorProgFilePath
    }

    # Deploy Image
    if ([DayZeroStagesJuniperASE]$dayZeroProgress.dayZeroStep -eq 4) {

        Write-Host -ForegroundColor Green "$newline$($newline)Begin day zero step: $([DayZeroStagesJuniperASE]$dayZeroProgress.dayZeroStep)$newline$newline"
        
        # Start a timer for day0 metrics
        $timer = [Diagnostics.Stopwatch]::StartNew()

        try {
            $dayZeroProgress.SSRImageName = (& $dayZeroMappings.DayZeroFilePaths.EdgeSSRImagePath `
                -ASEResourceID $dayZeroMappings.AzureStackEdgeInformation.AzureStackEdgeResourceID `
                -JuniperImageSASURI $dayZeroMappings.JuniperInformation.JuniperImageSASURI `
                -SSRImageTemplatePath $dayZeroMappings.DayZeroFilePaths.SSRImageTemplatePath `
                -CloudEnvironment $dayZeroMappings.AzureEnvironmentOptions.CloudEnvironment `
                -ASETenantID $dayZeroMappings.AzureStackEdgeInformation.AzureStackEdgeTenantID)
        }
        catch {
            $timer.stop()
            $dayZeroProgress.timer[$dayZeroProgress.dayZeroStep] += $timer.elapsed.totalseconds
            $dayZeroProgress.interruptions[$dayZeroProgress.dayZeroStep] += 1
            $dayZeroProgress | ConvertTo-Json | Set-Content $orchestratorProgFilePath

            Write-Error "Error occurred during Juniper SSR image download: $_"
            throw
        }

        $timer.stop()
        $dayZeroProgress.timer[$dayZeroProgress.dayZeroStep] += $timer.elapsed.totalseconds

        [DayZeroStagesJuniperASE]$dayZeroProgress.dayZeroStep = 5

        $dayZeroProgress | ConvertTo-Json | Set-Content $orchestratorProgFilePath
    }

    # Deploy VM 
    if ([DayZeroStagesJuniperASE]$dayZeroProgress.dayZeroStep -eq 5) {

        Write-Host -ForegroundColor Green "$newline$($newline)Begin day zero step: $([DayZeroStagesJuniperASE]$dayZeroProgress.dayZeroStep)$newline$newline"

        # We need to ensure that the dependencies of this step are present and valid
        switch ($dayZeroProgress) {
            { -not $_.SSRImageName } {
                $dayZeroProgress.SSRImageName = Read-Host "Did not find a valid value for the pre-existing Edge SSR image name. Please provide it now"
            }
            { -not $_.conductorPublicIp } {
                $dayZeroProgress.conductorPublicIp = Read-Host "Did not find a valid value for the Conductor's Public IP. Please provide it now"
            }
        }

        # Start a timer for day0 metrics
        $timer = [Diagnostics.Stopwatch]::StartNew()

        try {
            $dayZeroProgress.SSRVMName = (& $dayZeroMappings.DayZeroFilePaths.EdgeSSRVMPath `
                -ASEResourceID $dayZeroMappings.AzureStackEdgeInformation.AzureStackEdgeResourceID `
                -JuniperImageName $dayZeroProgress.SSRImageName `
                -SSRSSHPublicKey $dayZeroMappings.JuniperInformation.EdgeSSRSSHPublicKey `
                -SSRLanGatewayIP $dayZeroMappings.NetworkingInformation.DedicatedSSRLanGatewayIP `
                -SSRLanNetmask $dayZeroMappings.NetworkingInformation.DedicatedASELanSubnetMask `
                -SSRVMTemplatePath $dayZeroMappings.DayZeroFilePaths.SSRVMTemplatePath `
                -CloudEnvironment $dayZeroMappings.AzureEnvironmentOptions.CloudEnvironment `
                -CloudInitScriptPath $dayZeroMappings.DayZeroFilePaths.EdgeSSRCloudInitFilePath `
                -ConductorPublicIP $dayZeroProgress.conductorPublicIp `
                -ASETenantID $dayZeroMappings.AzureStackEdgeInformation.AzureStackEdgeTenantID)
        }
        catch {
            $timer.stop()
            $dayZeroProgress.timer[$dayZeroProgress.dayZeroStep] += $timer.elapsed.totalseconds
            $dayZeroProgress.interruptions[$dayZeroProgress.dayZeroStep] += 1
            $dayZeroProgress | ConvertTo-Json | Set-Content $orchestratorProgFilePath

            Write-Error "Error occurred when deploying the Juniper Edge SSR: $_"
            throw
        }

        $timer.stop()
        $dayZeroProgress.timer[$dayZeroProgress.dayZeroStep] += $timer.elapsed.totalseconds

        [DayZeroStagesJuniperASE]$dayZeroProgress.dayZeroStep = 6

        $dayZeroProgress | ConvertTo-Json | Set-Content $orchestratorProgFilePath
    }

    # Deploy CSE 
    if ([DayZeroStagesJuniperASE]$dayZeroProgress.dayZeroStep -eq 6) {

        Write-Host -ForegroundColor Green "$newline$($newline)Begin day zero step: $([DayZeroStagesJuniperASE]$dayZeroProgress.dayZeroStep)$newline$newline"

        # We need to ensure that the dependencies of this step are present and valid
        switch ($dayZeroProgress) {
            { -not $_.SSRVMName } {
                $dayZeroProgress.virtualNetworkName = Read-Host "Did not find a valid value for the pre-existing SSR Virtual Machine name. Please provide it now"
            }
        }

        # Start a timer for day0 metrics
        $timer = [Diagnostics.Stopwatch]::StartNew()

        $secondarySubnetMask = ($includesAsusRouter ? "" : $dayZeroMappings.NetworkingInformation.SecondaryNetworkSubnetMask)
        $secondaryGateway = ($includesAsusRouter ? "" : $dayZeroMappings.NetworkingInformation.SecondaryNetworkGatewayIP)
        
        try {
            $cseOutput = (& $dayZeroMappings.DayZeroFilePaths.SSRVMInfoPath `
                -TargetVM $dayZeroProgress.SSRVMName `
                -ASEResourceID $dayZeroMappings.AzureStackEdgeInformation.AzureStackEdgeResourceID `
                -ShellScriptPath $dayZeroMappings.DayZeroFilePaths.ShellScriptPath `
                -CustomScriptTemplatePath $dayZeroMappings.DayZeroFilePaths.CustomScriptTemplatePath `
                -CloudEnvironment $dayZeroMappings.AzureEnvironmentOptions.CloudEnvironment `
                -ASETenantID $dayZeroMappings.AzureStackEdgeInformation.AzureStackEdgeTenantID `
                -IncludesAsusRouter $includesAsusRouter `
                -SecondarySubnetMask $secondarySubnetMask `
                -SecondaryGateway $secondaryGateway)
        }
        catch {
            $timer.stop()
            $dayZeroProgress.timer[$dayZeroProgress.dayZeroStep] += $timer.elapsed.totalseconds
            $dayZeroProgress.interruptions[$dayZeroProgress.dayZeroStep] += 1
            $dayZeroProgress | ConvertTo-Json | Set-Content $orchestratorProgFilePath

            Write-Error "Error occurred when deploying a Custom Script Extension for the Juniper Edge SSR: $_"
            throw
        }

        $dayZeroProgress.satcomGatewayIp = $cseOutput.satcomGatewayIp
        $dayZeroProgress.satcomSubnet = $cseOutput.satcomSubnet
        $dayZeroProgress.satcomVmBusId = $cseOutput.satcomVmBusId
        $dayZeroProgress.satcomNicIp = $cseOutput.satcomNicIp

        $dayZeroProgress.wanGatewayIp = $cseOutput.wanGatewayIp
        $dayZeroProgress.wanSubnet = $cseOutput.wanSubnet
        $dayZeroProgress.wanVmBusId = $cseOutput.wanVmBusId
        $dayZeroProgress.wanNicIp = $cseOutput.wanNicIp

        $dayZeroProgress.lanGatewayIp = $cseOutput.lanGatewayIp
        $dayZeroProgress.lanSubnet = $cseOutput.lanSubnet
        $dayZeroProgress.lanVmBusId = $cseOutput.lanVmBusId
        $dayZeroProgress.lanNicIp = $cseOutput.lanNicIp

        $dayZeroProgress.edgeSsrAssetId = $cseOutput.assetId

        $timer.stop()
        $dayZeroProgress.timer[$dayZeroProgress.dayZeroStep] += $timer.elapsed.totalseconds

        [DayZeroStagesJuniperASE]$dayZeroProgress.dayZeroStep = 7

        $dayZeroProgress | ConvertTo-Json | Set-Content $orchestratorProgFilePath

    }

    # AOCA resource deployment
    if ([DayZeroStagesJuniperASE]$dayZeroProgress.dayZeroStep -eq 7) {

        Write-Host -ForegroundColor Green "$newline$($newline)Begin day zero step: $([DayZeroStagesJuniperASE]$dayZeroProgress.dayZeroStep)$newline$newline"
        
        # Start a timer for day0 metrics
        $timer = [Diagnostics.Stopwatch]::StartNew()

        # TODO ecaraballo: this will need to be updated to support the new API version that includes the DHCP flag
        try {    
            $dayZeroProgress = (& $dayZeroMappings.DayZeroFilePaths.AOCAResourceCreationScriptPath `
                -AOCAResourceJsonTemplateFilePath $dayZeroMappings.DayZeroFilePaths.AOCAResourceTemplateFilePath `
                -dayZeroMappings $dayZeroMappings `
                -dayZeroProgress $dayZeroProgress `
                -conductorSecret $juniperDefaultPassword `
                -orchestratorProgFilePath $orchestratorProgFilePath)
        }
        catch {
            $timer.stop()
            $dayZeroProgress.timer[$dayZeroProgress.dayZeroStep] += $timer.elapsed.totalseconds
            $dayZeroProgress.interruptions[$dayZeroProgress.dayZeroStep] += 1
            $dayZeroProgress | ConvertTo-Json | Set-Content $orchestratorProgFilePath

            Write-Error "Error occurred when deploying Azure Orbital Cloud Access resources: $_"
            throw
        }

        $timer.stop()
        $dayZeroProgress.timer[$dayZeroProgress.dayZeroStep] += $timer.elapsed.totalseconds

        # Proceed to step 8 if this is a no-asus router deployment
        [DayZeroStagesJuniperASE]$dayZeroProgress.dayZeroStep = ($includesAsusRouter ? 7 : 8)
        $dayZeroProgress | ConvertTo-Json | Set-Content $orchestratorProgFilePath

        Write-Host -ForegroundColor Green "Azure Orbital Cloud Access resources have been successfully created!$newline"

        # Emit day0 Metrics using custom script extension
        Write-Host -ForegroundColor Yellow "Storing run data..."

        $dayZeroCseResult = Emit-DayZeroMetrics `
                -dayZeroMappings $dayZeroMappings `
                -dayZeroInterruptions $dayZeroProgress.interruptions `
                -dayZeroTimer $dayZeroProgress.timer

        Write-Host -ForegroundColor Green "Run data stored successfully!"
    }

    # Remove bootstrapper NIC config from ASE
    if ([DayZeroStagesJuniperASE]$dayZeroProgress.dayZeroStep -eq 8) {

        Write-Host -ForegroundColor Green "$newline$($newline)Begin day zero step: $([DayZeroStagesJuniperASE]$dayZeroProgress.dayZeroStep)$newline$newline"

        # Preferable to not be on bootstrapper port, as connectivity would break mid modification
        $suppressDecision = Receive-UserConfirmation -Prompt "Please ensure the following:$newline - The ASSET IDs have been associated in the Conductor if not automatically associated.$newline - The Azure Orbital Cloud Access agent has been fully deployed and is running on your Azure Stack Edge.$newline - You are connected to the Azure Stack Edge LAN port$newline - Your bootstrapper port has been physically disconnected AFTER AOCA agent has been deployed$newline$($newline)Press Y to continue..." `
            -DeclineMessage "Please re-run this script once you are ready." `
            -IsTerminating

        try {    
            (& $dayZeroMappings.DayZeroFilePaths.SetASELanScriptPath `
                -ASESerial $dayZeroMappings.AzureStackEdgeInformation.AzureStackEdgeNodeSerialNumber `
                -ASEPassword $aseLocalPassword `
                -LANIP $dayZeroMappings.NetworkingInformation.DedicatedASELanIP `
                -ZtpRestHelpersPath $dayZeroMappings.DayZeroFilePaths.ZtpRestHelpersPath `
                -ClearBootstrapperConfig `
                -BootstrapperPort $dayZeroMappings.NetworkingInformation.BootstrapperPortNumber)
        }
        catch {
            Write-Error "Error occurred when removing bootstrapper configuration: $_"
            throw
        }
    }

    Rename-Item -Path $orchestratorProgFilePath -NewName "orchestrator-progress.$(Get-Date -f yyyyMddHHmm).tmp"

    Write-Host -ForegroundColor Green "Day zero has completed successfully! Please refer to Azure Orbital Cloud Access documentation for next steps."
}

<#
    .SYNOPSIS
    This function runs all the necessary steps to get a no-sdwan deployment on an ASE up and running for a customer
#>
function Start-NoSdwanASEDayZero() {
    param(
        [parameter(mandatory)]
        [PSObject]
        $dayZeroMappings,
        [parameter(mandatory)]
        [Boolean]
        $includesAsusRouter
    )

    $preSharedKey = ([Convert]::ToBase64String((1..128|%{[byte](Get-Random -Max 256)}))).Substring(0, 128)
    
    enum DayZeroStagesNSDASE {
        vSwitchCreation = 1
        AzureNetworkingDeployment = 2
        AOCAResourceDeployment = 3
        PostDeploymentAgentSettings = 4
        DisableBootstrapperHostNic = 5
    }
    # Check for progress file, create it if it does not exist
    if (Test-Path -Path $orchestratorProgFilePath -PathType Leaf) {
        $existingProgress = Get-Content -Path $orchestratorProgFilePath | ConvertFrom-Json

        if ($existingProgress.dayZeroStep) {
            $dayZeroProgress = @{
                dayZeroStep=$existingProgress.dayZeroStep; `
                vpnGatewayResourceId=$existingProgress.vpnGatewayResourceId; `
                vpnGatewayConnectionResourceId=$existingProgress.vpnGatewayConnectionResourceId; `
                vpnGatewayPublicIpResourceId=$existingProgress.vpnGatewayPublicIpResourceId; `
                vpnGwPip=$existingProgress.vpnGwPip; `
                rightId=$existingProgress.rightId; `
                rightSubnet=$existingProgress.rightSubnet; `
                starlinkIp=$existingProgress.starlinkIp; `
                firewallPip=$existingProgress.firewallPip; `
                timer=$existingProgress.timer; `
                interruptions=$existingProgress.interruptions; `
            }
        }
    } 

    if (-not $dayZeroProgress) {
        $dayZeroProgress = @{dayZeroStep=1;vpnGatewayResourceId="";vpnGatewayConnectionResourceId="";vpnGatewayPublicIpResourceId="";vpnGwPip="";rightId="";rightSubnet="";starlinkIp="";firewallPip="";timer = 0,0,0,0,0;interruptions = 0,0,0,0,0}
        $dayZeroProgress | ConvertTo-Json | Set-Content $orchestratorProgFilePath
    }

    $timer.stop()
    $dayZeroProgress.timer[0] += $timer.elapsed.totalseconds

    # Prompt user for various passwords, based off what step in the day-zero process they are in
    switch ($dayZeroProgress.dayZeroStep) {
        { [DayZeroStagesNSDASE]$_ -le 1 -or -not $includesAsusRouter} {
            do {
                $aseLocalPassword = Read-Host -AsSecureString "Please enter your password for the Azure Stack Edge's local UI"
            }
            while ($aseLocalPassword.Length -eq 0)
        }
        { [DayZeroStagesNSDASE]$_ -le 2 } {
            do {
                $connectionPeerId = Read-Host "Please provide a VPN Gateway Connection peer ID string between 8 and 12 characters"
            }
            while ($connectionPeerId.Length -lt 8 -or $connectionPeerId.Length -gt 12)

            $targetRegion = ($dayZeroMappings.AzureInformation.TargetRegion).ToLower()

            $vpnGwSku = Get-VPNGatewaySKU -targetRegion $targetRegion `
                -cloudType $dayZeroMappings.AzureEnvironmentOptions.CloudEnvironment
        }
    }

    $newline = [System.Environment]::NewLine

    # vSwitch Configuration
    if ([DayZeroStagesNSDASE]$dayZeroProgress.dayZeroStep -eq 1) {

        Write-Host -ForegroundColor Green "$newline$($newline)Begin day zero step: $([DayZeroStagesNSDASE]$dayZeroProgress.dayZeroStep)$newline$newline"
        
        # Start a timer for day0 metrics
        $timer = [Diagnostics.Stopwatch]::StartNew()

        try {

            (& $dayZeroMappings.DayZeroFilePaths.SetASELanScriptPath `
                -ASESerial $dayZeroMappings.AzureStackEdgeInformation.AzureStackEdgeNodeSerialNumber `
                -ASEPassword $aseLocalPassword `
                -LANIP $dayZeroMappings.NetworkingInformation.DedicatedASELanIP `
                -SubnetMask $dayZeroMappings.NetworkingInformation.DedicatedASELanSubnetMask `
                -LANGateway $dayZeroMappings.NetworkingInformation.LanGatewayIP `
                -ZtpRestHelpersPath $dayZeroMappings.DayZeroFilePaths.ZtpRestHelpersPath)
        }
        catch {
            $timer.stop()
            $dayZeroProgress.timer[$dayZeroProgress.dayZeroStep] += $timer.elapsed.totalseconds
            $dayZeroProgress.interruptions[$dayZeroProgress.dayZeroStep] += 1
            $dayZeroProgress | ConvertTo-Json | Set-Content $orchestratorProgFilePath

            Write-Error "Error occurred when configuring Azure Stack Edge virtual switches: $_"
            throw
        }

        $timer.stop()
        $dayZeroProgress.timer[$dayZeroProgress.dayZeroStep] += $timer.elapsed.totalseconds

        Write-Host -ForegroundColor Cyan "From this point forward, please have a device or switch plugged into the LAN port so that it is powered on."

        [DayZeroStagesNSDASE]$dayZeroProgress.dayZeroStep = 2

        $dayZeroProgress | ConvertTo-Json | Set-Content $orchestratorProgFilePath
    }

    # Convert ASE LAN to CIDR format
    $cidr = (Convert-Subnetmask -Mask $dayZeroMappings.NetworkingInformation.DedicatedASELanSubnetMask).CIDR
    $subnet = ([IPAddress] (([IPAddress] $dayZeroMappings.NetworkingInformation.LanGatewayIP).Address -band ([IPAddress] $dayZeroMappings.NetworkingInformation.DedicatedASELanSubnetMask).Address)).ToString()

    $edgeLanSubnetPrefix = $subnet + "/" + $cidr

    # Azure resource deployment
    if ([DayZeroStagesNSDASE]$dayZeroProgress.dayZeroStep -eq 2) {

        Write-Host -ForegroundColor Green "$newline$($newline)Begin day zero step: $([DayZeroStagesNSDASE]$dayZeroProgress.dayZeroStep)$newline$newline"

        # Start a timer for day0 metrics
        $timer = [Diagnostics.Stopwatch]::StartNew()

        try {    
            $azResourceOutput = (& $dayZeroMappings.DayZeroFilePaths.AzureDeploymentFilePath `
                -dayZeroMappings $dayZeroMappings `
                -edgeLanSubnetCidr $edgeLanSubnetPrefix `
                -connectionPeerId $connectionPeerId `
                -connectionPreSharedKey $preSharedKey `
                -vpnGwSku $vpnGwSku)

            $dayZeroProgress.vpnGatewayResourceId = $azResourceOutput.Outputs.vpnGwId.Value
            $dayZeroProgress.vpnGatewayConnectionResourceId = $azResourceOutput.Outputs.connectionId.Value
            $dayZeroProgress.vpnGatewayPublicIpResourceId = $azResourceOutput.Outputs.vpnGwPipId.Value
            $dayZeroProgress.vpnGwPip = $azResourceOutput.Outputs.vpnGatewayPublicIpAddress.Value
            $dayZeroProgress.rightId = $azResourceOutput.Outputs.peerId.Value
            $dayZeroProgress.rightSubnet = $edgeLanSubnetPrefix
            $dayZeroProgress.starlinkIp = ($includesAsusRouter ? $dayZeroMappings.NetworkingInformation.SatcomAvailableIP : "Retrieve this information from the ASE resource in Azure Portal.")
            $dayZeroProgress.firewallPip = $azResourceOutput.Outputs.firewallPublicIpAddress.Value

        }
        catch {
            $timer.stop()
            $dayZeroProgress.timer[$dayZeroProgress.dayZeroStep] += $timer.elapsed.totalseconds
            $dayZeroProgress.interruptions[$dayZeroProgress.dayZeroStep] += 1
            $dayZeroProgress | ConvertTo-Json | Set-Content $orchestratorProgFilePath

            Write-Error "Error occurred when deploying Azure resources: $_"
            throw
        }

        $timer.stop()
        $dayZeroProgress.timer[$dayZeroProgress.dayZeroStep] += $timer.elapsed.totalseconds
                
        [DayZeroStagesNSDASE]$dayZeroProgress.dayZeroStep = 3

        $dayZeroProgress | ConvertTo-Json | Set-Content $orchestratorProgFilePath
    }

    # AOCA resource deployment
    if ([DayZeroStagesNSDASE]$dayZeroProgress.dayZeroStep -eq 3) {

        Write-Host -ForegroundColor Green "$newline$($newline)Begin day zero step: $([DayZeroStagesNSDASE]$dayZeroProgress.dayZeroStep)$newline$newline"

        # Start a timer for day0 metrics
        $timer = [Diagnostics.Stopwatch]::StartNew()

        try {    
            $aocaResourceOutput = (& $dayZeroMappings.DayZeroFilePaths.AOCAResourceCreationScriptPath `
                -dayZeroMappings $dayZeroMappings `
                -vpnGatewayResourceId $dayZeroProgress.vpnGatewayResourceId `
                -vpnGatewayConnectionResourceId $dayZeroProgress.vpnGatewayConnectionResourceId `
                -vpnGatewayPublicIpResourceId $dayZeroProgress.vpnGatewayPublicIpResourceId `
                -edgeLanSubnetCidr $edgeLanSubnetPrefix `
                -AOCANoSdwanResourceJsonTemplateFilePath $dayZeroMappings.DayZeroFilePaths.AOCAResourceTemplateFilePath `
                -IncludesAsusRouter $includesAsusRouter)
        }
        catch {
            $timer.stop()
            $dayZeroProgress.timer[$dayZeroProgress.dayZeroStep] += $timer.elapsed.totalseconds
            $dayZeroProgress.interruptions[$dayZeroProgress.dayZeroStep] += 1
            $dayZeroProgress | ConvertTo-Json | Set-Content $orchestratorProgFilePath

            Write-Error "Error occurred when deploying Azure Orbital Cloud Access resources: $_"
            throw
        }

        $timer.stop()
        $dayZeroProgress.timer[$dayZeroProgress.dayZeroStep] += $timer.elapsed.totalseconds

        # Proceed to step 4 if this is a no-asus router deployment
        [DayZeroStagesNSDASE]$dayZeroProgress.dayZeroStep = ($includesAsusRouter ? 3 : 4)
        $dayZeroProgress | ConvertTo-Json | Set-Content $orchestratorProgFilePath

        Write-Host -ForegroundColor Green "Azure Orbital Cloud Access resources have been successfully created!"

        if (-not $includesAsusRouter) {
            Write-Host -ForegroundColor Green "Before proceeding, please wait for the Azure Orbital Cloud Access agent to be fully deployed to your Azure Stack Edge (ASE), which can be confirmed via the ASE resource on the Azure Portal."
            $suppressDecision = Receive-UserConfirmation -Prompt "Press Y if you're ready to proceed." `
                -DeclineMessage "Once you are ready, you can simply re-run this script." `
                -IsTerminating
        }

    }
    
    # Post-deployment AOCA agent settings via Custom Script Extension
    if ([DayZeroStagesNSDASE]$dayZeroProgress.dayZeroStep -eq 4) {
        $allowInternetBreakout = [System.Convert]::ToBoolean($dayZeroMappings.AzureInformation.AllowInternetBreakout)

        # Start a timer for day0 metrics
        $timer = [Diagnostics.Stopwatch]::StartNew()

        # For SATCOM and no-asus deployment, configure agent SNAT settings using Custom Script Extension
        if (-not $includesAsusRouter -and -not $allowInternetBreakout) {
            Write-Host -ForegroundColor Green "$newline$($newline)Begin day zero step: $([DayZeroStagesNSDASE]$dayZeroProgress.dayZeroStep)$newline$newline"
            Write-Host -ForegroundColor Yellow "Applying post-deployment Azure Orbital Cloud Access agent settings..."

            try {
                # Get the name of the newly-deployed AOCA agent
                $agentVmName = Watch-AocaAgentVmDeployment `
                    -targetAseId $dayZeroMappings.AzureStackEdgeInformation.AzureStackEdgeResourceID `
                    -targetAseTenantId $dayZeroMappings.AzureStackEdgeInformation.AzureStackEdgeTenantID `
                    -cloudEnvironment $dayZeroMappings.AzureEnvironmentOptions.CloudEnvironment

                # Build token replacement mapping the below cmdlet will use to replace __aseIp__ in script with correct value
                $scriptReplacements = New-Object "System.Collections.Generic.Dictionary[[String],[String]]"
                $scriptReplacements.Add("___aseIp___", $dayZeroMappings.NetworkingInformation.DedicatedASELanIP)

                # Invoke Custom Script Extension request to apply SNAT script to agent VM
                $cseResult = Invoke-CustomScriptExtensionRequest `
                    -dayZeroMappings $dayZeroMappings `
                    -targetVmName $agentVmName `
                    -scriptReplacements $scriptReplacements `
                    -scriptPath $dayZeroMappings.DayZeroFilePaths.SNATScriptFilePath
            }
            catch {
                $timer.stop()
                $dayZeroProgress.timer[$dayZeroProgress.dayZeroStep] += $timer.elapsed.totalseconds
                $dayZeroProgress.interruptions[$dayZeroProgress.dayZeroStep] += 1
                $dayZeroProgress | ConvertTo-Json | Set-Content $orchestratorProgFilePath

                Write-Error "Error occured when applying post-deployment Azure Orbital Cloud Access agent settings: $_"
                throw
            }

            Write-Host -ForegroundColor Green "Post-deployment Azure Orbital Cloud Access agent settings were applied successfully!"
        }

        $timer.stop()
        $dayZeroProgress.timer[$dayZeroProgress.dayZeroStep] += $timer.elapsed.totalseconds

        # Once finished, set progress file to the next step
        [DayZeroStagesNSDASE]$dayZeroProgress.dayZeroStep = 5
        $dayZeroProgress | ConvertTo-Json | Set-Content $orchestratorProgFilePath

        # Emit day0 Metrics using custom script extension
        Write-Host -ForegroundColor Yellow "Storing run data..."

        $dayZeroCseResult = Emit-DayZeroMetrics `
                -dayZeroMappings $dayZeroMappings `
                -dayZeroInterruptions $dayZeroProgress.interruptions `
                -dayZeroTimer $dayZeroProgress.timer

        Write-Host -ForegroundColor Green "Run data stored successfully!"
    }

    # Remove bootstrapper NIC info from ASE
    if ([DayZeroStagesNSDASE]$dayZeroProgress.dayZeroStep -eq 5) {

        Write-Host -ForegroundColor Green "$newline$($newline)Begin day zero step: $([DayZeroStagesNSDASE]$dayZeroProgress.dayZeroStep)$newline$newline"

        # Preferable to not be on bootstrapper port, as connectivity would break mid modification        
        $suppressDecision = Receive-UserConfirmation -Prompt "Please ensure that you are connected to the Azure Stack Edge LAN port from this point forward, and that your bootstrapper port has been physically disconnected. Press Y to continue..." `
            -DeclineMessage "Please re-run this script once you are ready." `
            -IsTerminating

        try {    
            (& $dayZeroMappings.DayZeroFilePaths.SetASELanScriptPath `
                -ASESerial $dayZeroMappings.AzureStackEdgeInformation.AzureStackEdgeNodeSerialNumber `
                -ASEPassword $aseLocalPassword `
                -LANIP $dayZeroMappings.NetworkingInformation.DedicatedASELanIP `
                -ZtpRestHelpersPath $dayZeroMappings.DayZeroFilePaths.ZtpRestHelpersPath `
                -ClearBootstrapperConfig `
                -BootstrapperPort $dayZeroMappings.NetworkingInformation.BootstrapperPortNumber)
        }
        catch {
            Write-Error "Error occurred when removing bootstrapper configuration: $_"
            throw
        }
    }

    Rename-Item -Path $orchestratorProgFilePath -NewName "orchestrator-progress.$(Get-Date -f yyyyMddHHmm).tmp"

    Write-Host -ForegroundColor Green "$($newline)All relevant resources for Azure Orbital Cloud Access have been deployed! Please provide the following information to your Microsoft Project Manager contact:"
    
    # Output line by line as a hash table does not guarantee output order. This info is for the create tunnel action.
    Write-Host -ForegroundColor Green "Endpoint : " -NoNewline; Write-Host "$($dayZeroMappings.AzureInformation.TargetRegion)"
    Write-Host -ForegroundColor Green "subscriptionId : " -NoNewline; Write-Host "$($dayZeroMappings.AzureInformation.TargetSubscriptionID)"
    Write-Host -ForegroundColor Green "resourceGroupName : " -NoNewline; Write-Host "$($dayZeroMappings.AzureInformation.TargetResourceGroupName)"
    Write-Host -ForegroundColor Green "terminalName : " -NoNewline; Write-Host "$($dayZeroMappings.AzureInformation.AOCAResourcePrefix)-terminal"
    Write-Host -ForegroundColor Green "Vpn Gw Pip : " -NoNewline; Write-Host "$($dayZeroProgress.vpnGwPip)"
    Write-Host -ForegroundColor Green "Right Id : " -NoNewline; Write-Host "$($dayZeroProgress.rightId)"
    Write-Host -ForegroundColor Green "Right Subnet : " -NoNewline; Write-Host "$($dayZeroProgress.rightSubnet)"
    Write-Host -ForegroundColor Green "Firewall Pip : " -NoNewline; Write-Host "$($dayZeroProgress.firewallPip)"
}

# Start a timer for day0 metrics
$timer = [Diagnostics.Stopwatch]::StartNew()

# Ensure the customer is using the expected PowerShell version (7.0 or higher)
$userPSVersionMajor = $PSVersionTable.PSVersion.Major
$userPSVersionMinor = $PSVersionTable.PSVersion.Minor

if ($userPSVersionMajor -ne 7) {
    Write-Error "Detected PowerShell version $userPSVersionMajor.$userPSVersionMinor; please ensure you are on approved versions 7.0 or higher"
    exit
}

# Unblock files to prevent security warning popups
Get-ChildItem .\* -Recurse | Unblock-File

# Ensure the Az Resources module is installed
Install-Module -Name Az.Resources -AllowClobber -Scope CurrentUser -Force
Install-Module -Name Az.Network -AllowClobber -Scope CurrentUser -Force
Install-Module -Name Az.Compute -AllowClobber -Scope CurrentUser -Force
Install-Module -Name Az.KeyVault -AllowClobber -Scope CurrentUser -Force

# Import helper module
Import-Module $DayZeroHelpersFilePath -Force


$newline = [System.Environment]::NewLine

try {
    $cleanedInput = Remove-ScriptSpecialCharacters -scriptPath $DayZeroInputFilePath
    $joinedInput = $cleanedInput -join ""
}
catch {
    Write-Error "Unable to find DayZeroInputFilePath, please make sure the provided path is correct. $newline $newline$($_.Exception.Message)"
    exit
}

try {
    $dayZeroMappings = $joinedInput | ConvertFrom-Json
}
catch {
    Write-Error "Something went wrong when converting input file to JSON. Please check formatting and try again. $newline $newline$($_.Exception.Message)"
    exit
}

enum CloudAccessVariations {
    ASEJuniperSDWAN
    ASENoSDWAN
}

$cloudAccessVariant = $dayZeroMappings.SysInfo.CloudAccessVariant
$dayZeroMappings.AzureEnvironmentOptions.CloudEnvironment = ($dayZeroMappings.AzureEnvironmentOptions.CloudEnvironment).ToLower()

if ($cloudAccessVariant -eq [CloudAccessVariations]::ASEJuniperSDWAN) {

    Start-JuniperASEDayZero -dayZeroMappings $dayZeroMappings -includesAsusRouter $dayZeroMappings.SysInfo.IncludesAsusRouter

}
elseif ($cloudAccessVariant -eq [CloudAccessVariations]::ASENoSDWAN) {

    Start-NoSdwanASEDayZero -dayZeroMappings $dayZeroMappings -includesAsusRouter $dayZeroMappings.SysInfo.IncludesAsusRouter
}
else {
    Write-Error "Invalid SysInfo.TemplateValue"
    throw
}